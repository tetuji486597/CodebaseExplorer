// Stage 2: Parallel file analysis - stub, implemented in Step 3
import { supabase } from '../db/supabase.js';
import { callClaudeStructured } from '../ai/claude.js';
import { fileAnalysisSchema } from '../ai/schemas.js';

export interface FileAnalysis {
  path: string;
  purpose: string;
  concepts: string[];
  key_exports: Array<{ name: string; what_it_does: string }>;
  depends_on: string[];
  complexity: string;
  role: string;
}

export async function runFileAnalysis(
  projectId: string,
  fileContents: Record<string, string>,
  framework: string,
  fileTree: any
): Promise<FileAnalysis[]> {
  const allFiles = Object.entries(fileContents);
  const allAnalyses: FileAnalysis[] = [];

  // Batch files: 5-8 per batch
  const batchSize = 6;
  const batches: Array<[string, string][]> = [];

  for (let i = 0; i < allFiles.length; i += batchSize) {
    batches.push(allFiles.slice(i, i + batchSize));
  }

  // Process up to 5 batches in parallel
  const concurrency = 5;
  for (let i = 0; i < batches.length; i += concurrency) {
    const batchGroup = batches.slice(i, i + concurrency);

    const results = await Promise.all(
      batchGroup.map(async (batch) => {
        const fileDescriptions = batch
          .map(([path, content]) => {
            const truncated = content.substring(0, 3000);
            return `<file path="${path}">\n${truncated}\n</file>`;
          })
          .join('\n\n');

        try {
          const result = await callClaudeStructured<{ files: FileAnalysis[] }>({
            system: `You are a senior software engineer analyzing code files. Analyze each file and output structured JSON.
The project uses ${framework}. Respond with ONLY valid JSON matching the schema, no markdown.`,
            prompt: `Analyze these files and return a JSON object with a "files" array. For each file include: path, purpose (one sentence), concepts (high-level ideas it implements), key_exports (name + what_it_does), depends_on (file paths it imports from), complexity (simple/moderate/complex), role (entry_point/core_logic/data/ui/utility/config/test/types).

${fileDescriptions}`,
            schema: fileAnalysisSchema,
            schemaName: 'file_analysis',
            maxTokens: 4096,
          });

          return result.files;
        } catch (err) {
          console.error('File analysis batch failed:', err);
          // Return minimal analysis for failed batch
          return batch.map(([path]) => ({
            path,
            purpose: 'Analysis failed',
            concepts: [],
            key_exports: [],
            depends_on: [],
            complexity: 'moderate' as const,
            role: 'source' as const,
          }));
        }
      })
    );

    allAnalyses.push(...results.flat());
  }

  // Store analyses in files table
  for (const analysis of allAnalyses) {
    await supabase
      .from('files')
      .update({ analysis: analysis as any })
      .eq('project_id', projectId)
      .eq('path', analysis.path);
  }

  return allAnalyses;
}
