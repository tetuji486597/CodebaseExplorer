// Stage 3: Concept synthesis
import { supabase } from '../db/supabase.js';
import { callClaudeStructured } from '../ai/claude.js';
import { conceptSynthesisSchema } from '../ai/schemas.js';
import type { FileAnalysis } from './fileAnalysis.js';

export interface ConceptSynthesisResult {
  concepts: Array<{
    id: string;
    name: string;
    emoji: string;
    color: string;
    metaphor: string;
    one_liner: string;
    explanation: string;
    deep_explanation: string;
    file_ids: string[];
    importance: string;
  }>;
  edges: Array<{
    source: string;
    target: string;
    relationship: string;
    strength: string;
  }>;
  suggested_starting_concept: string;
  codebase_summary: string;
}

export async function runConceptSynthesis(
  projectId: string,
  fileAnalyses: FileAnalysis[],
  fileTree: any,
  framework: string
): Promise<ConceptSynthesisResult> {
  const analysisText = fileAnalyses
    .map(
      (f) =>
        `File: ${f.path}
Purpose: ${f.purpose}
Concepts: ${f.concepts.join(', ')}
Exports: ${f.key_exports.map((e) => e.name).join(', ')}
Role: ${f.role}
Complexity: ${f.complexity}
Dependencies: ${f.depends_on.join(', ')}`
    )
    .join('\n\n');

  const allPaths = fileAnalyses.map((f) => f.path);

  const raw = await callClaudeStructured<any>({
    system: `You are synthesizing a concept map from file analyses. Create meaningful concepts that group related files.

You MUST return a JSON object with EXACTLY these fields:
{
  "concepts": [
    {
      "id": "short_key",
      "name": "Human Readable Name",
      "emoji": "single emoji",
      "color": "teal|purple|coral|blue|amber|pink|green|gray",
      "metaphor": "real-world analogy",
      "one_liner": "10 words max",
      "explanation": "2-3 sentences, plain English",
      "deep_explanation": "2-3 paragraphs, more technical",
      "file_ids": ["array of file paths"],
      "importance": "critical|important|supporting"
    }
  ],
  "edges": [
    { "source": "concept_id", "target": "concept_id", "relationship": "description", "strength": "strong|moderate|weak" }
  ],
  "suggested_starting_concept": "concept_id",
  "codebase_summary": "2-3 sentences"
}`,
    prompt: `This is a ${framework} project with ${fileAnalyses.length} files.

File paths: ${allPaths.join(', ')}

File analyses:
${analysisText}

Create a concept map with 3-20 concepts (scale with complexity). Every file must belong to exactly one concept. Use the exact JSON field names shown in the system prompt.`,
    schema: conceptSynthesisSchema,
    schemaName: 'concept_synthesis',
    maxTokens: 8192,
  });

  // Normalize Claude's response — it sometimes uses different field names
  const normalizeConcept = (c: any) => ({
    id: c.id || c.key || 'unknown',
    name: c.name || c.label || c.title || c.id || 'Unnamed',
    emoji: c.emoji || c.icon || '📦',
    color: c.color || 'gray',
    metaphor: c.metaphor || c.analogy || '',
    one_liner: c.one_liner || c.oneLiner || c.summary || '',
    explanation: c.explanation || c.description || c.detail || '',
    deep_explanation: c.deep_explanation || c.deepExplanation || c.explanation || c.description || '',
    file_ids: Array.isArray(c.file_ids) ? c.file_ids : Array.isArray(c.files) ? c.files : Array.isArray(c.fileIds) ? c.fileIds : [],
    importance: c.importance || c.priority || 'supporting',
  });

  const normalizeEdge = (e: any) => ({
    source: e.source || e.from || '',
    target: e.target || e.to || '',
    relationship: e.relationship || e.label || e.description || 'related to',
    strength: e.strength || e.weight || 'moderate',
  });

  const result: ConceptSynthesisResult = {
    concepts: (raw.concepts || []).map(normalizeConcept),
    edges: (raw.edges || []).map(normalizeEdge),
    suggested_starting_concept: raw.suggested_starting_concept || raw.suggestedStartingConcept || raw.startingConcept || (raw.concepts?.[0]?.id || ''),
    codebase_summary: raw.codebase_summary || raw.codebaseSummary || raw.summary || '',
  };

  // Store concepts
  console.log(`Storing ${result.concepts.length} concepts for project ${projectId}`);
  for (const concept of result.concepts) {
    const { error: conceptError } = await supabase.from('concepts').insert({
      project_id: projectId,
      concept_key: concept.id,
      name: concept.name,
      emoji: concept.emoji,
      color: concept.color,
      metaphor: concept.metaphor,
      one_liner: concept.one_liner,
      explanation: concept.explanation,
      deep_explanation: concept.deep_explanation,
      importance: concept.importance,
    });
    if (conceptError) {
      console.error(`Failed to insert concept ${concept.id}:`, conceptError);
    }

    // Update files with concept_id
    for (const filePath of concept.file_ids) {
      await supabase
        .from('files')
        .update({ concept_id: concept.id })
        .eq('project_id', projectId)
        .eq('path', filePath);
    }
  }

  // Store edges
  for (const edge of result.edges) {
    if (!edge.source || !edge.target) continue;
    const { error: edgeError } = await supabase.from('concept_edges').insert({
      project_id: projectId,
      source_concept_key: edge.source,
      target_concept_key: edge.target,
      relationship: edge.relationship,
      strength: edge.strength,
    });
    if (edgeError) {
      console.error(`Failed to insert edge ${edge.source}->${edge.target}:`, edgeError);
    }
  }

  // Update project summary
  await supabase
    .from('projects')
    .update({ summary: result.codebase_summary })
    .eq('id', projectId);

  return result;
}
