import Anthropic from '@anthropic-ai/sdk';
import 'dotenv/config';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
});

const MAIN_MODEL = 'claude-sonnet-4-6';
const FAST_MODEL = 'claude-haiku-4-5-20251001';

export interface StructuredCallOptions {
  system: string;
  prompt: string;
  schema: Record<string, unknown>;
  schemaName: string;
  maxTokens?: number;
  model?: 'main' | 'fast';
}

export async function callClaudeStructured<T>(opts: StructuredCallOptions): Promise<T> {
  const model = opts.model === 'fast' ? FAST_MODEL : MAIN_MODEL;

  const response = await anthropic.messages.create({
    model,
    max_tokens: opts.maxTokens || 4096,
    system: opts.system + '\n\nIMPORTANT: You MUST respond with ONLY a valid JSON object. No markdown, no code blocks, no explanatory text. Just the raw JSON.',
    messages: [{ role: 'user', content: opts.prompt }],
  });

  // Extract text from response
  const textBlock = response.content.find((b) => b.type === 'text');
  if (!textBlock || textBlock.type !== 'text') {
    throw new Error('No text response from Claude');
  }

  // Parse JSON from response - try multiple extraction strategies
  let jsonStr = textBlock.text.trim();

  // Strategy 1: Extract from markdown code blocks
  const jsonMatch = jsonStr.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (jsonMatch) {
    jsonStr = jsonMatch[1].trim();
  }

  // Strategy 2: Find the first { and last } to extract JSON object
  if (!jsonStr.startsWith('{') && !jsonStr.startsWith('[')) {
    const firstBrace = jsonStr.indexOf('{');
    const lastBrace = jsonStr.lastIndexOf('}');
    if (firstBrace !== -1 && lastBrace !== -1) {
      jsonStr = jsonStr.substring(firstBrace, lastBrace + 1);
    }
  }

  return JSON.parse(jsonStr) as T;
}

export async function streamClaude(opts: {
  system: string;
  messages: Array<{ role: 'user' | 'assistant'; content: string }>;
  maxTokens?: number;
  model?: 'main' | 'fast';
}): Promise<AsyncIterable<string>> {
  const model = opts.model === 'fast' ? FAST_MODEL : MAIN_MODEL;

  const stream = anthropic.messages.stream({
    model,
    max_tokens: opts.maxTokens || 1024,
    system: opts.system,
    messages: opts.messages,
  });

  return {
    async *[Symbol.asyncIterator]() {
      for await (const event of stream) {
        if (event.type === 'content_block_delta' && event.delta.type === 'text_delta') {
          yield event.delta.text;
        }
      }
    },
  };
}

export { anthropic, MAIN_MODEL, FAST_MODEL };
