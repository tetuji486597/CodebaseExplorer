import useStore from '../store/useStore';

export default function TopBar() {
  const { viewMode, setViewMode, concepts } = useStore();

  return (
    <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between px-4 py-3"
         style={{ background: 'rgba(15, 15, 14, 0.85)', backdropFilter: 'blur(8px)', borderBottom: '0.5px solid #282826' }}>
      {/* Left: Title */}
      <div className="flex items-center gap-2">
        <span className="text-base">🧭</span>
        <span className="text-sm font-medium" style={{ color: '#E8E8E6' }}>Codebase Explorer</span>
        {concepts.length > 0 && (
          <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: '#282826', color: '#888' }}>
            {concepts.length} concepts
          </span>
        )}
      </div>

      {/* Center: View Toggle */}
      <div className="flex rounded-lg overflow-hidden" style={{ background: '#1A1A18', border: '0.5px solid #333' }}>
        <button
          onClick={() => setViewMode('concepts')}
          className="px-3 py-1.5 text-xs font-medium transition-all"
          style={{
            background: viewMode === 'concepts' ? 'rgba(159,225,203,0.12)' : 'transparent',
            color: viewMode === 'concepts' ? '#9FE1CB' : '#666',
          }}
        >
          Concepts
        </button>
        <button
          onClick={() => setViewMode('files')}
          className="px-3 py-1.5 text-xs font-medium transition-all"
          style={{
            background: viewMode === 'files' ? 'rgba(159,225,203,0.12)' : 'transparent',
            color: viewMode === 'files' ? '#9FE1CB' : '#666',
          }}
        >
          Files
        </button>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => useStore.getState().setScreen('upload')}
          className="text-xs px-2.5 py-1.5 rounded-lg transition-all active:scale-95"
          style={{ color: '#888', background: 'transparent' }}
          onMouseEnter={e => e.target.style.background = '#282826'}
          onMouseLeave={e => e.target.style.background = 'transparent'}
        >
          New
        </button>
      </div>
    </div>
  );
}
