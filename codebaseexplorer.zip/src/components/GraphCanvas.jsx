import { useRef, useEffect, useState, useCallback } from 'react';
import useStore from '../store/useStore';
import { CONCEPT_COLORS } from '../data/sampleData';
import { createConceptLayout, createFileLayout } from '../utils/graphLayout';

const DPR = typeof window !== 'undefined' ? Math.min(window.devicePixelRatio || 1, 2) : 1;

export default function GraphCanvas() {
  const canvasRef = useRef(null);
  const animFrameRef = useRef(null);
  const nodesRef = useRef([]);
  const linksRef = useRef([]);
  const transformRef = useRef({ x: 0, y: 0, scale: 1 });
  const dragRef = useRef({ isDragging: false, startX: 0, startY: 0, startTX: 0, startTY: 0 });
  const hoverNodeRef = useRef(null);
  const timeRef = useRef(0);
  const sizeRef = useRef({ w: 0, h: 0 });
  const touchRef = useRef({ lastDist: 0 });
  const transitionRef = useRef({ active: false, progress: 0, fromNodes: [], toNodes: [] });

  const {
    concepts, files, conceptEdges, fileImports,
    viewMode, selectedNode, setSelectedNode, clearSelection, setShowInspector,
    getFilesByConcept, pulsingNodeId, connectionHighlight,
  } = useStore();

  const [layoutReady, setLayoutReady] = useState(false);

  // Compute layouts
  useEffect(() => {
    if (!concepts.length) return;
    const canvas = canvasRef.current;
    if (!canvas) return;

    const w = canvas.parentElement.clientWidth;
    const h = canvas.parentElement.clientHeight;
    sizeRef.current = { w, h };

    const conceptLayout = createConceptLayout(concepts, conceptEdges, w, h);

    if (viewMode === 'concepts') {
      nodesRef.current = conceptLayout.nodes.map(n => ({
        ...n,
        type: 'concept',
        fileCount: files.filter(f => f.conceptId === n.id).length,
        floatOffset: Math.random() * Math.PI * 2,
        floatSpeed: 3 + Math.random() * 2,
      }));
      linksRef.current = conceptLayout.links;
    } else {
      // Pass concept positions to file layout
      const conceptsWithPositions = conceptLayout.nodes;
      const fileLayout = createFileLayout(files, conceptsWithPositions, fileImports, w, h);
      nodesRef.current = fileLayout.nodes.map(n => ({
        ...n,
        type: 'file',
        floatOffset: Math.random() * Math.PI * 2,
        floatSpeed: 3 + Math.random() * 2,
      }));
      linksRef.current = fileLayout.links;
    }

    // Center the view
    transformRef.current = { x: 0, y: 0, scale: 1 };
    setLayoutReady(true);
  }, [concepts, files, conceptEdges, fileImports, viewMode]);

  // Get color for a node
  const getNodeColor = useCallback((node) => {
    if (node.type === 'concept') {
      return CONCEPT_COLORS[node.color] || CONCEPT_COLORS.gray;
    }
    const concept = concepts.find(c => c.id === node.conceptId);
    return CONCEPT_COLORS[concept?.color] || CONCEPT_COLORS.gray;
  }, [concepts]);

  // Draw function
  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const { w, h } = sizeRef.current;
    const t = transformRef.current;
    const time = timeRef.current;

    ctx.clearRect(0, 0, w * DPR, h * DPR);
    ctx.save();
    ctx.scale(DPR, DPR);

    // Background
    ctx.fillStyle = '#0F0F0E';
    ctx.fillRect(0, 0, w, h);

    // Subtle grid
    ctx.strokeStyle = 'rgba(255,255,255,0.02)';
    ctx.lineWidth = 0.5;
    const gridSize = 40 * t.scale;
    const offsetX = (t.x % gridSize);
    const offsetY = (t.y % gridSize);
    for (let x = offsetX; x < w; x += gridSize) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
    }
    for (let y = offsetY; y < h; y += gridSize) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
    }

    ctx.save();
    ctx.translate(t.x, t.y);
    ctx.scale(t.scale, t.scale);

    const nodes = nodesRef.current;
    const links = linksRef.current;
    const selected = selectedNode;

    // Determine connected node IDs
    const connectedIds = new Set();
    if (selected) {
      connectedIds.add(selected.id);
      links.forEach(l => {
        const sid = typeof l.source === 'object' ? l.source.id : l.source;
        const tid = typeof l.target === 'object' ? l.target.id : l.target;
        if (sid === selected.id) connectedIds.add(tid);
        if (tid === selected.id) connectedIds.add(sid);
      });
    }

    // Draw concept cluster clouds in files view
    if (viewMode === 'files' && concepts.length) {
      concepts.forEach(concept => {
        const conceptFiles = nodes.filter(n => n.conceptId === concept.id);
        if (conceptFiles.length < 2) return;

        const colors = CONCEPT_COLORS[concept.color] || CONCEPT_COLORS.gray;
        const cx = conceptFiles.reduce((s, f) => s + f.x, 0) / conceptFiles.length;
        const cy = conceptFiles.reduce((s, f) => s + f.y, 0) / conceptFiles.length;
        const maxDist = Math.max(...conceptFiles.map(f => Math.hypot(f.x - cx, f.y - cy))) + 30;

        ctx.beginPath();
        ctx.arc(cx, cy, maxDist, 0, Math.PI * 2);
        ctx.strokeStyle = colors.stroke + '20';
        ctx.setLineDash([4, 4]);
        ctx.lineWidth = 1;
        ctx.stroke();
        ctx.setLineDash([]);

        ctx.fillStyle = colors.stroke + '08';
        ctx.fill();
      });
    }

    // Draw edges
    links.forEach(link => {
      const source = typeof link.source === 'object' ? link.source : nodes.find(n => n.id === link.source);
      const target = typeof link.target === 'object' ? link.target : nodes.find(n => n.id === link.target);
      if (!source || !target) return;

      let opacity = 0.15;
      if (selected) {
        const sid = source.id;
        const tid = target.id;
        if (connectedIds.has(sid) && connectedIds.has(tid)) {
          opacity = 0.6;
        } else {
          opacity = 0.04;
        }
      }

      ctx.beginPath();
      ctx.moveTo(source.x, source.y);

      // Curved edges
      const midX = (source.x + target.x) / 2;
      const midY = (source.y + target.y) / 2;
      const dx = target.x - source.x;
      const dy = target.y - source.y;
      const cx2 = midX - dy * 0.1;
      const cy2 = midY + dx * 0.1;
      ctx.quadraticCurveTo(cx2, cy2, target.x, target.y);

      ctx.strokeStyle = `rgba(255, 255, 255, ${opacity})`;
      ctx.lineWidth = viewMode === 'concepts' ? 1.5 : 0.8;
      ctx.stroke();

      // Edge label for concept view
      if (viewMode === 'concepts' && link.label && opacity > 0.1 && t.scale > 0.6) {
        ctx.save();
        ctx.fillStyle = `rgba(255, 255, 255, ${opacity * 0.7})`;
        ctx.font = `${9 / Math.max(t.scale, 0.5)}px -apple-system, sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillText(link.label, cx2, cy2 - 4);
        ctx.restore();
      }
    });

    // Draw nodes
    nodes.forEach(node => {
      const colors = getNodeColor(node);
      const isSelected = selected?.id === node.id;
      const isConnected = selected ? connectedIds.has(node.id) : true;
      const isHovered = hoverNodeRef.current === node.id;
      const isPulsing = useStore.getState().pulsingNodeId === node.id;

      // Float animation
      const floatY = Math.sin(time / 1000 * (2 * Math.PI / node.floatSpeed) + node.floatOffset) * 3;
      const drawX = node.x;
      const drawY = node.y + floatY;

      const nodeOpacity = selected && !isConnected ? 0.2 : 1;

      ctx.save();
      ctx.globalAlpha = nodeOpacity;

      if (node.type === 'concept') {
        const r = node.radius || 35;
        const displayR = isSelected ? r * 1.06 : isHovered ? r * 1.03 : r;

        // Glow for selected or pulsing
        if (isSelected) {
          ctx.beginPath();
          ctx.arc(drawX, drawY, displayR + 8, 0, Math.PI * 2);
          ctx.fillStyle = colors.stroke + '25';
          ctx.fill();
        }
        if (isPulsing && !isSelected) {
          const pulseSize = 6 + Math.sin(time / 500) * 4;
          const pulseAlpha = Math.floor(20 + Math.sin(time / 500) * 15).toString(16).padStart(2, '0');
          ctx.beginPath();
          ctx.arc(drawX, drawY, displayR + pulseSize, 0, Math.PI * 2);
          ctx.fillStyle = colors.stroke + pulseAlpha;
          ctx.fill();
          ctx.beginPath();
          ctx.arc(drawX, drawY, displayR + pulseSize + 6, 0, Math.PI * 2);
          ctx.strokeStyle = colors.stroke + '15';
          ctx.lineWidth = 1;
          ctx.stroke();
        }

        // Fill
        ctx.beginPath();
        ctx.arc(drawX, drawY, displayR, 0, Math.PI * 2);
        ctx.fillStyle = colors.fill;
        ctx.fill();

        // Stroke
        ctx.strokeStyle = colors.stroke;
        ctx.lineWidth = isSelected ? 2.5 : 1.5;
        ctx.stroke();

        // Emoji
        ctx.font = `${Math.round(displayR * 0.6)}px serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(node.emoji || '📦', drawX, drawY - 2);

        // Label below
        ctx.font = `500 ${Math.max(10, Math.round(displayR * 0.32))}px -apple-system, BlinkMacSystemFont, sans-serif`;
        ctx.textAlign = 'center';
        ctx.fillStyle = colors.text;
        ctx.fillText(node.name, drawX, drawY + displayR + 14);

        // File count badge
        if (node.fileCount) {
          const badgeText = `${node.fileCount} files`;
          ctx.font = '9px -apple-system, sans-serif';
          ctx.fillStyle = colors.text + 'aa';
          ctx.fillText(badgeText, drawX, drawY + displayR + 26);
        }
      } else {
        // File node
        const r = node.radius || 8;
        const displayR = isSelected ? r * 1.2 : isHovered ? r * 1.1 : r;

        if (isSelected) {
          ctx.beginPath();
          ctx.arc(drawX, drawY, displayR + 4, 0, Math.PI * 2);
          ctx.fillStyle = colors.stroke + '25';
          ctx.fill();
        }

        ctx.beginPath();
        ctx.arc(drawX, drawY, displayR, 0, Math.PI * 2);
        ctx.fillStyle = colors.fill;
        ctx.fill();
        ctx.strokeStyle = colors.stroke;
        ctx.lineWidth = isSelected ? 2 : 1;
        ctx.stroke();

        // File name label (only when zoomed in enough or selected)
        if (t.scale > 0.7 || isSelected || isHovered) {
          ctx.font = `400 ${Math.max(8, 10 / Math.max(t.scale, 0.5))}px 'SF Mono', monospace`;
          ctx.textAlign = 'center';
          ctx.fillStyle = colors.text + (isSelected || isHovered ? 'ff' : '99');
          ctx.fillText(node.name, drawX, drawY + displayR + 10);
        }
      }

      ctx.restore();
    });

    ctx.restore();
    ctx.restore();

    timeRef.current += 16;
    animFrameRef.current = requestAnimationFrame(draw);
  }, [concepts, viewMode, selectedNode, getNodeColor]);

  // Start animation loop
  useEffect(() => {
    if (!layoutReady) return;
    animFrameRef.current = requestAnimationFrame(draw);
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [draw, layoutReady]);

  // Resize handler
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const resize = () => {
      const parent = canvas.parentElement;
      const w = parent.clientWidth;
      const h = parent.clientHeight;
      canvas.width = w * DPR;
      canvas.height = h * DPR;
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      sizeRef.current = { w, h };
    };

    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, []);

  // Hit testing
  const hitTest = useCallback((clientX, clientY) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const t = transformRef.current;

    const canvasX = (clientX - rect.left - t.x) / t.scale;
    const canvasY = (clientY - rect.top - t.y) / t.scale;

    // Check nodes in reverse (top-most first)
    for (let i = nodesRef.current.length - 1; i >= 0; i--) {
      const node = nodesRef.current[i];
      const r = node.radius || (node.type === 'concept' ? 35 : 8);
      const hitR = r + 5; // Generous hit area
      if (Math.hypot(canvasX - node.x, canvasY - node.y) < hitR) {
        return node;
      }
    }
    return null;
  }, []);

  // Mouse/touch handlers
  const handlePointerDown = useCallback((e) => {
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;

    if (e.touches && e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      touchRef.current.lastDist = Math.hypot(dx, dy);
      return;
    }

    dragRef.current = {
      isDragging: true,
      startX: clientX,
      startY: clientY,
      startTX: transformRef.current.x,
      startTY: transformRef.current.y,
      moved: false,
    };
  }, []);

  const handlePointerMove = useCallback((e) => {
    if (e.touches && e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      const scale = dist / touchRef.current.lastDist;
      transformRef.current.scale = Math.max(0.2, Math.min(3, transformRef.current.scale * scale));
      touchRef.current.lastDist = dist;
      return;
    }

    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;

    if (dragRef.current.isDragging) {
      const dx = clientX - dragRef.current.startX;
      const dy = clientY - dragRef.current.startY;
      if (Math.abs(dx) > 3 || Math.abs(dy) > 3) dragRef.current.moved = true;
      transformRef.current.x = dragRef.current.startTX + dx;
      transformRef.current.y = dragRef.current.startTY + dy;
    } else {
      // Hover detection (mouse only)
      if (!e.touches) {
        const hit = hitTest(clientX, clientY);
        const canvas = canvasRef.current;
        if (hit) {
          canvas.style.cursor = 'pointer';
          hoverNodeRef.current = hit.id;
        } else {
          canvas.style.cursor = 'grab';
          hoverNodeRef.current = null;
        }
      }
    }
  }, [hitTest]);

  const handlePointerUp = useCallback((e) => {
    if (!dragRef.current.isDragging) return;

    if (!dragRef.current.moved) {
      const clientX = e.changedTouches ? e.changedTouches[0].clientX : e.clientX;
      const clientY = e.changedTouches ? e.changedTouches[0].clientY : e.clientY;
      const hit = hitTest(clientX, clientY);

      if (hit) {
        setSelectedNode({ type: hit.type, id: hit.id });
        setShowInspector(true);
      } else {
        clearSelection();
        setShowInspector(false);
      }
    }

    dragRef.current.isDragging = false;
  }, [hitTest, setSelectedNode, clearSelection, setShowInspector]);

  const handleWheel = useCallback((e) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const zoom = e.deltaY < 0 ? 1.08 : 0.92;
    const newScale = Math.max(0.2, Math.min(3, transformRef.current.scale * zoom));
    const ratio = newScale / transformRef.current.scale;

    transformRef.current.x = mouseX - ratio * (mouseX - transformRef.current.x);
    transformRef.current.y = mouseY - ratio * (mouseY - transformRef.current.y);
    transformRef.current.scale = newScale;
  }, []);

  // Keyboard handler
  useEffect(() => {
    const handleKey = (e) => {
      if (e.key === 'Escape') {
        clearSelection();
        setShowInspector(false);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [clearSelection, setShowInspector]);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full"
      style={{ touchAction: 'none' }}
      onMouseDown={handlePointerDown}
      onMouseMove={handlePointerMove}
      onMouseUp={handlePointerUp}
      onMouseLeave={() => { dragRef.current.isDragging = false; hoverNodeRef.current = null; }}
      onTouchStart={handlePointerDown}
      onTouchMove={handlePointerMove}
      onTouchEnd={handlePointerUp}
      onWheel={handleWheel}
    />
  );
}
