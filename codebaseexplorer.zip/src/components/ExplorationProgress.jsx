import useStore from '../store/useStore';

export default function ExplorationProgress() {
  const explorationProgress = useStore(s => s.explorationProgress);
  const suggestionBanner = useStore(s => s.suggestionBanner);
  const setSuggestionBanner = useStore(s => s.setSuggestionBanner);

  if (explorationProgress === 0 && !suggestionBanner) return null;

  return (
    <div className="absolute top-14 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2">
      {/* Suggestion banner */}
      {suggestionBanner && (
        <div
          className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs"
          style={{
            background: 'rgba(26, 26, 24, 0.9)',
            border: '0.5px solid #333',
            backdropFilter: 'blur(8px)',
            color: '#9FE1CB',
            animation: 'fade-in 0.3s ease-out',
          }}
        >
          <span style={{ color: '#FAC775' }}>→</span>
          <span>{suggestionBanner}</span>
          <button
            onClick={() => setSuggestionBanner(null)}
            className="ml-1 text-xs"
            style={{ color: '#555' }}
          >
            ✕
          </button>
        </div>
      )}

      {/* Progress bar */}
      {explorationProgress > 0 && (
        <div
          className="flex items-center gap-2 px-3 py-1 rounded-full text-xs"
          style={{
            background: 'rgba(26, 26, 24, 0.85)',
            border: '0.5px solid #282826',
            backdropFilter: 'blur(8px)',
          }}
        >
          <div className="w-20 h-1 rounded-full overflow-hidden" style={{ background: '#282826' }}>
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{
                width: `${Math.round(explorationProgress * 100)}%`,
                background: 'linear-gradient(90deg, #9FE1CB, #CECBF6)',
              }}
            />
          </div>
          <span style={{ color: '#888' }}>
            {Math.round(explorationProgress * 100)}% explored
          </span>
        </div>
      )}
    </div>
  );
}
