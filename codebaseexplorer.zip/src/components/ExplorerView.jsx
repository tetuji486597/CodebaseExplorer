import TopBar from './TopBar';
import GraphCanvas from './GraphCanvas';
import InspectorPanel from './InspectorPanel';
import ChatBar from './ChatBar';
import CodePanel from './CodePanel';
import Onboarding from './Onboarding';
import InsightCard from './InsightCard';
import ExplorationProgress from './ExplorationProgress';
import useUserState from '../hooks/useUserState';
import useProactive from '../hooks/useProactive';

export default function ExplorerView() {
  // Activate user state tracking and proactive engine
  useUserState();
  useProactive();

  return (
    <div className="w-full h-full relative" style={{ background: '#0F0F0E' }}>
      <TopBar />
      <GraphCanvas />
      <InspectorPanel />
      <ExplorationProgress />
      <InsightCard />
      <ChatBar />
      <CodePanel />
      <Onboarding />
    </div>
  );
}
