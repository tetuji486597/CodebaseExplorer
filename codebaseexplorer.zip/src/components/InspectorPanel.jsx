import { useMemo, useState, useEffect } from 'react';
import useStore from '../store/useStore';
import { CONCEPT_COLORS } from '../data/sampleData';

export default function InspectorPanel() {
  const {
    selectedNode, showInspector, setShowInspector, clearSelection,
    concepts, files, conceptEdges, projectId,
    openCodePanel, addChatMessage, setChatLoading,
  } = useStore();

  const [explanation, setExplanation] = useState(null);
  const [streamingExplanation, setStreamingExplanation] = useState('');
  const [loadingExplanation, setLoadingExplanation] = useState(false);

  const node = useMemo(() => {
    if (!selectedNode) return null;
    if (selectedNode.type === 'concept') {
      return concepts.find(c => c.id === selectedNode.id);
    }
    return files.find(f => f.id === selectedNode.id);
  }, [selectedNode, concepts, files]);

  const concept = useMemo(() => {
    if (!node) return null;
    if (selectedNode?.type === 'concept') return node;
    return concepts.find(c => c.id === node.conceptId);
  }, [node, selectedNode, concepts]);

  const colors = concept ? (CONCEPT_COLORS[concept.color] || CONCEPT_COLORS.gray) : CONCEPT_COLORS.gray;

  const conceptFiles = useMemo(() => {
    if (!concept) return [];
    return files.filter(f => f.conceptId === concept.id);
  }, [concept, files]);

  const relatedEdges = useMemo(() => {
    if (!concept || selectedNode?.type !== 'concept') return [];
    return conceptEdges.filter(e => e.source === concept.id || e.target === concept.id);
  }, [concept, selectedNode, conceptEdges]);

  // Fetch explanation from backend when selecting a concept
  useEffect(() => {
    if (!selectedNode || !projectId || selectedNode.type !== 'concept') {
      setExplanation(null);
      return;
    }

    const fetchExplanation = async () => {
      setLoadingExplanation(true);
      setStreamingExplanation('');
      try {
        const res = await fetch('/api/explain', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            projectId,
            conceptKey: selectedNode.id,
            userLevel: 'beginner',
          }),
        });

        const contentType = res.headers.get('content-type');
        if (contentType?.includes('application/json')) {
          // Pre-generated explanation
          const data = await res.json();
          setExplanation(data.explanation);
          setLoadingExplanation(false);
        } else {
          // SSE stream
          const reader = res.body.getReader();
          const decoder = new TextDecoder();
          let accumulated = '';
          let buffer = '';

          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';
            for (const line of lines) {
              if (line.startsWith('data: ')) {
                try {
                  const data = JSON.parse(line.slice(6));
                  if (data.text) {
                    accumulated += data.text;
                    setStreamingExplanation(accumulated);
                  }
                  if (data.done) {
                    setExplanation(accumulated);
                    setStreamingExplanation('');
                  }
                } catch {}
              }
            }
          }
          setLoadingExplanation(false);
        }
      } catch {
        setLoadingExplanation(false);
      }
    };

    fetchExplanation();
  }, [selectedNode, projectId]);

  if (!showInspector || !node) return null;

  const handleAskClaude = () => {
    const name = node.name || node.id;
    addChatMessage({
      role: 'user',
      content: `Tell me about ${name} in plain English — what does it do, what should I watch out for?`,
    });
    setChatLoading(true);

    if (projectId) {
      // Real chat will be handled by ChatBar's submit
      // Just trigger it by updating the message
      setChatLoading(false);
    } else {
      setTimeout(() => {
        addChatMessage({
          role: 'assistant',
          content: `**${node.name || node.id}** ${node.description || 'is a key part of this application.'}`,
        });
        setChatLoading(false);
      }, 800);
    }
  };

  const close = () => {
    setShowInspector(false);
    clearSelection();
  };

  const displayDescription = explanation || streamingExplanation || node.description || node.explanation || '';

  return (
    <div
      className="absolute top-0 right-0 h-full z-30 overflow-y-auto"
      style={{
        width: 'min(380px, 90vw)',
        background: '#1A1A18',
        borderLeft: '0.5px solid #333',
        animation: 'slide-in-right 0.3s ease-out',
      }}
    >
      {/* Header */}
      <div className="sticky top-0 z-10 flex items-center justify-between p-4"
           style={{ background: '#1A1A18', borderBottom: '0.5px solid #282826' }}>
        <div className="flex items-center gap-2">
          {selectedNode.type === 'concept' ? (
            <>
              <span className="text-xl">{node.emoji}</span>
              <span className="font-medium text-sm" style={{ color: '#E8E8E6' }}>{node.name}</span>
            </>
          ) : (
            <>
              <div className="w-2.5 h-2.5 rounded-full" style={{ background: colors.stroke }} />
              <span className="mono text-sm" style={{ color: '#E8E8E6' }}>{node.name}</span>
            </>
          )}
        </div>
        <button
          onClick={close}
          className="w-7 h-7 rounded-lg flex items-center justify-center text-sm transition-colors"
          style={{ color: '#888', background: 'transparent' }}
          onMouseEnter={e => e.target.style.background = '#282826'}
          onMouseLeave={e => e.target.style.background = 'transparent'}
        >
          ✕
        </button>
      </div>

      <div className="p-4 space-y-5">
        {/* Concept badge for file view */}
        {selectedNode.type === 'file' && concept && (
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs"
               style={{ background: colors.fill, color: colors.text, border: `1px solid ${colors.stroke}40` }}>
            <span>{concept.emoji}</span>
            <span>{concept.name}</span>
          </div>
        )}

        {/* Importance badge */}
        {selectedNode.type === 'concept' && node.importance && (
          <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs"
               style={{
                 background: node.importance === 'critical' ? 'rgba(245,196,179,0.1)' : 'rgba(255,255,255,0.05)',
                 color: node.importance === 'critical' ? '#F5C4B3' : '#888',
               }}>
            {node.importance}
          </div>
        )}

        {/* Metaphor */}
        {selectedNode.type === 'concept' && node.metaphor && (
          <div className="text-xs italic" style={{ color: '#888' }}>
            "{node.metaphor}"
          </div>
        )}

        {/* Description / Explanation */}
        <div>
          {loadingExplanation && !streamingExplanation ? (
            <div className="flex items-center gap-2 text-xs" style={{ color: '#888' }}>
              <div className="w-1.5 h-1.5 rounded-full" style={{ background: '#9FE1CB', animation: 'processing-dot 1.4s infinite' }} />
              Loading explanation...
            </div>
          ) : (
            <p className="text-sm leading-relaxed" style={{ color: '#BBB' }}>
              {displayDescription}
              {streamingExplanation && (
                <span className="inline-block w-1.5 h-3 ml-0.5 rounded-sm" style={{ background: '#9FE1CB', animation: 'processing-dot 1s infinite' }} />
              )}
            </p>
          )}
        </div>

        {/* Concept-specific content */}
        {selectedNode.type === 'concept' && (
          <>
            <div className="flex items-center gap-2 text-xs" style={{ color: '#888' }}>
              <span style={{ color: colors.stroke }}>{conceptFiles.length}</span> files in this concept
            </div>

            <div>
              <div className="text-xs font-medium mb-2" style={{ color: '#888' }}>Files</div>
              <div className="flex flex-wrap gap-1.5">
                {conceptFiles.map(f => (
                  <button
                    key={f.id}
                    onClick={() => {
                      useStore.getState().setSelectedNode({ type: 'file', id: f.id });
                    }}
                    className="mono text-xs px-2 py-1 rounded-md transition-all active:scale-95"
                    style={{
                      background: colors.fill + '80',
                      color: colors.text,
                      border: `0.5px solid ${colors.stroke}30`,
                    }}
                    onMouseEnter={e => e.target.style.background = colors.fill}
                    onMouseLeave={e => e.target.style.background = colors.fill + '80'}
                  >
                    {f.name}
                  </button>
                ))}
              </div>
            </div>

            {relatedEdges.length > 0 && (
              <div>
                <div className="text-xs font-medium mb-2" style={{ color: '#888' }}>Connections</div>
                <div className="space-y-1.5">
                  {relatedEdges.map((edge, i) => {
                    const isSource = edge.source === concept.id;
                    const otherId = isSource ? edge.target : edge.source;
                    const other = concepts.find(c => c.id === otherId);
                    if (!other) return null;
                    const otherColors = CONCEPT_COLORS[other.color] || CONCEPT_COLORS.gray;
                    return (
                      <button
                        key={i}
                        onClick={() => {
                          useStore.getState().setSelectedNode({ type: 'concept', id: otherId });
                        }}
                        className="flex items-center gap-2 text-xs w-full text-left transition-all rounded p-1 -ml-1"
                        style={{ color: '#AAA' }}
                        onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,0.03)'}
                        onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                      >
                        <span>{isSource ? '→' : '←'}</span>
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded"
                              style={{ background: otherColors.fill + '60' }}>
                          <span>{other.emoji}</span>
                          <span style={{ color: otherColors.text }}>{other.name}</span>
                        </span>
                        <span style={{ color: '#666' }}>{edge.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}

        {/* File-specific content */}
        {selectedNode.type === 'file' && (
          <>
            {node.exports && node.exports.length > 0 && (
              <div>
                <div className="text-xs font-medium mb-2" style={{ color: '#888' }}>Exports</div>
                <div className="flex flex-wrap gap-1.5">
                  {node.exports.map((exp, i) => (
                    <span key={i} className="mono text-xs px-2 py-0.5 rounded"
                          style={{ background: '#282826', color: '#AAA' }}>
                      {exp}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <button
              onClick={() => openCodePanel(node.id)}
              className="w-full py-2.5 rounded-xl text-sm font-medium transition-all active:scale-[0.98]"
              style={{
                background: colors.fill,
                color: colors.text,
                border: `1px solid ${colors.stroke}40`,
              }}
            >
              Walk me through this file
            </button>
          </>
        )}

        <button
          onClick={handleAskClaude}
          className="w-full py-2.5 rounded-xl text-sm font-medium transition-all active:scale-[0.98]"
          style={{
            background: 'rgba(255,255,255,0.05)',
            color: '#CCC',
            border: '0.5px solid #333',
          }}
          onMouseEnter={e => e.target.style.background = 'rgba(255,255,255,0.08)'}
          onMouseLeave={e => e.target.style.background = 'rgba(255,255,255,0.05)'}
        >
          Ask Claude about this
        </button>
      </div>
    </div>
  );
}
