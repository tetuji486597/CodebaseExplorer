import { useState, useEffect } from 'react';
import useStore from '../store/useStore';

const STEPS = [
  { text: 'Reading your files...', emoji: '📂', stage: 0 },
  { text: 'Analyzing code structure...', emoji: '🔍', stage: 2 },
  { text: 'Synthesizing concepts...', emoji: '🧩', stage: 3 },
  { text: 'Adding depth & insights...', emoji: '💡', stage: 4 },
  { text: 'Indexing for search...', emoji: '🔎', stage: 6 },
  { text: 'Building your map...', emoji: '🗺️', stage: 7 },
];

export default function ProcessingScreen() {
  const { processingStatus, pipelineProgress } = useStore();
  const [dots, setDots] = useState([]);
  const [activeStep, setActiveStep] = useState(0);

  useEffect(() => {
    // Update active step based on pipeline progress or processingStatus text
    if (pipelineProgress?.stage) {
      const stage = pipelineProgress.stage;
      const stepIdx = STEPS.findIndex((s, i) => {
        const nextStage = STEPS[i + 1]?.stage ?? 99;
        return stage >= s.stage && stage < nextStage;
      });
      if (stepIdx >= 0) setActiveStep(stepIdx);
    } else {
      // Fallback to text matching for demo mode
      if (processingStatus.includes('Reading') || processingStatus.includes('Loading')) setActiveStep(0);
      else if (processingStatus.includes('Analyzing') || processingStatus.includes('Extract')) setActiveStep(1);
      else if (processingStatus.includes('Synth') || processingStatus.includes('Finding')) setActiveStep(2);
      else if (processingStatus.includes('depth') || processingStatus.includes('insight')) setActiveStep(3);
      else if (processingStatus.includes('Index') || processingStatus.includes('search')) setActiveStep(4);
      else if (processingStatus.includes('Building') || processingStatus.includes('exploration')) setActiveStep(5);
    }
  }, [processingStatus, pipelineProgress]);

  // Generate floating constellation dots
  useEffect(() => {
    const newDots = Array.from({ length: 30 }, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: 2 + Math.random() * 4,
      duration: 3 + Math.random() * 4,
      delay: Math.random() * 3,
      color: ['#9FE1CB', '#CECBF6', '#F5C4B3', '#B5D4F4', '#FAC775', '#F4C0D1'][Math.floor(Math.random() * 6)],
    }));
    setDots(newDots);
  }, []);

  return (
    <div className="w-full h-full flex flex-col items-center justify-center relative"
         style={{ background: '#0F0F0E' }}>

      {/* Floating dots constellation */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {dots.map(dot => (
          <div
            key={dot.id}
            className="absolute rounded-full"
            style={{
              left: `${dot.x}%`,
              top: `${dot.y}%`,
              width: `${dot.size}px`,
              height: `${dot.size}px`,
              background: dot.color,
              opacity: 0.3,
              animation: `float ${dot.duration}s ease-in-out infinite ${dot.delay}s`,
            }}
          />
        ))}

        {/* Lines connecting some dots */}
        <svg className="absolute inset-0 w-full h-full" style={{ opacity: 0.08 }}>
          {dots.slice(0, 15).map((dot, i) => {
            const next = dots[(i + 3) % dots.length];
            return (
              <line
                key={i}
                x1={`${dot.x}%`} y1={`${dot.y}%`}
                x2={`${next.x}%`} y2={`${next.y}%`}
                stroke={dot.color}
                strokeWidth="0.5"
              />
            );
          })}
        </svg>
      </div>

      {/* Central processing indicator */}
      <div className="z-10 text-center" style={{ animation: 'fade-in 0.5s ease-out' }}>
        {/* Pulsing rings */}
        <div className="relative w-24 h-24 mx-auto mb-8">
          <div className="absolute inset-0 rounded-full border"
               style={{ borderColor: 'rgba(159, 225, 203, 0.2)', animation: 'pulse-scale 2s ease-in-out infinite' }} />
          <div className="absolute inset-2 rounded-full border"
               style={{ borderColor: 'rgba(206, 203, 246, 0.2)', animation: 'pulse-scale 2s ease-in-out infinite 0.3s' }} />
          <div className="absolute inset-4 rounded-full border"
               style={{ borderColor: 'rgba(250, 199, 117, 0.2)', animation: 'pulse-scale 2s ease-in-out infinite 0.6s' }} />
          <div className="absolute inset-0 flex items-center justify-center text-3xl">
            {STEPS[activeStep]?.emoji || '🧭'}
          </div>
        </div>

        {/* Current status message */}
        <p className="text-sm mb-6" style={{ color: '#9FE1CB' }}>
          {processingStatus || 'Starting...'}
        </p>

        {/* Steps */}
        <div className="space-y-3">
          {STEPS.map((step, i) => (
            <div key={i} className="flex items-center justify-center gap-3 transition-all duration-500"
                 style={{
                   opacity: i <= activeStep ? 1 : 0.3,
                   transform: i <= activeStep ? 'translateY(0)' : 'translateY(5px)',
                 }}>
              <div className="w-2 h-2 rounded-full transition-all duration-500"
                   style={{
                     background: i < activeStep ? '#9FE1CB' : i === activeStep ? '#9FE1CB' : '#333',
                     boxShadow: i === activeStep ? '0 0 8px rgba(159, 225, 203, 0.5)' : 'none',
                   }} />
              <span className="text-sm" style={{
                color: i <= activeStep ? '#E8E8E6' : '#555',
                fontWeight: i === activeStep ? 500 : 400,
              }}>
                {step.text}
              </span>
              {i < activeStep && (
                <span className="text-xs" style={{ color: '#9FE1CB' }}>✓</span>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
