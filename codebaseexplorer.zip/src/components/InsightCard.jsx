import { useState } from 'react';
import useStore from '../store/useStore';

const CATEGORY_COLORS = {
  architecture: '#B5D4F4',
  risk: '#F5C4B3',
  pattern: '#CECBF6',
  praise: '#9FE1CB',
  suggestion: '#FAC775',
  complexity: '#F4C0D1',
};

const CATEGORY_ICONS = {
  architecture: '🏗️',
  risk: '⚠️',
  pattern: '🔄',
  praise: '✨',
  suggestion: '💡',
  complexity: '🧩',
};

export default function InsightCard() {
  const { insightCard, setInsightCard } = useStore();
  const [expanded, setExpanded] = useState(false);

  if (!insightCard) return null;

  const color = CATEGORY_COLORS[insightCard.category] || '#D3D1C7';
  const icon = CATEGORY_ICONS[insightCard.category] || '💡';

  const dismiss = () => {
    setInsightCard(null);
    setExpanded(false);
  };

  return (
    <div
      className="absolute bottom-20 left-1/2 -translate-x-1/2 z-30 w-full max-w-md mx-4"
      style={{ animation: 'fade-in 0.3s ease-out' }}
    >
      <div
        className="rounded-xl overflow-hidden"
        style={{
          background: '#1A1A18',
          border: `1px solid ${color}30`,
          boxShadow: `0 4px 24px rgba(0,0,0,0.4), 0 0 0 1px ${color}10`,
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3"
             style={{ borderBottom: `0.5px solid ${color}20` }}>
          <div className="flex items-center gap-2">
            <span className="text-base">{icon}</span>
            <span className="text-xs font-medium uppercase tracking-wide" style={{ color: color + 'cc' }}>
              {insightCard.category}
            </span>
          </div>
          <button
            onClick={dismiss}
            className="w-6 h-6 rounded flex items-center justify-center text-xs"
            style={{ color: '#666' }}
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="px-4 py-3">
          <h3 className="text-sm font-medium mb-1" style={{ color: '#E8E8E6' }}>
            {insightCard.title}
          </h3>
          <p className="text-xs leading-relaxed" style={{ color: '#999' }}>
            {insightCard.summary}
          </p>

          {expanded && (
            <p className="text-xs leading-relaxed mt-2" style={{ color: '#BBB', animation: 'fade-in 0.2s ease-out' }}>
              {insightCard.detail}
            </p>
          )}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2 px-4 py-2" style={{ borderTop: `0.5px solid ${color}10` }}>
          {!expanded && insightCard.detail && (
            <button
              onClick={() => setExpanded(true)}
              className="text-xs px-2 py-1 rounded transition-all"
              style={{ color, background: color + '10' }}
            >
              Tell me more
            </button>
          )}
          <button
            onClick={dismiss}
            className="text-xs px-2 py-1 rounded transition-all"
            style={{ color: '#666' }}
          >
            Dismiss
          </button>
        </div>
      </div>
    </div>
  );
}
