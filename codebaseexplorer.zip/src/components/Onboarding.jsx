import { useState } from 'react';
import useStore from '../store/useStore';

const STEPS = [
  {
    title: 'This is your concept map',
    description: 'Each bubble represents a part of the app. Colors group related features. Bigger bubbles mean more code is involved.',
    emoji: '🗺️',
  },
  {
    title: 'Tap any bubble',
    description: 'Select a concept or file to see what it does, which files it contains, and how it connects to everything else.',
    emoji: '👆',
  },
  {
    title: 'Ask anything',
    description: 'Use the chat bar at the bottom to ask questions about the codebase in plain English. No coding knowledge required.',
    emoji: '💬',
  },
];

export default function Onboarding() {
  const { showOnboarding, onboardingStep, setOnboardingStep, dismissOnboarding } = useStore();

  if (!showOnboarding) return null;

  const step = STEPS[onboardingStep];
  const isLast = onboardingStep === STEPS.length - 1;

  const next = () => {
    if (isLast) {
      dismissOnboarding();
    } else {
      setOnboardingStep(onboardingStep + 1);
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center"
         style={{ background: 'rgba(15, 15, 14, 0.85)', backdropFilter: 'blur(4px)' }}>
      <div className="w-full max-w-sm mx-4 rounded-2xl p-6 text-center"
           style={{ background: '#1A1A18', border: '0.5px solid #333', animation: 'fade-in 0.3s ease-out' }}>

        {/* Step indicator */}
        <div className="flex justify-center gap-1.5 mb-5">
          {STEPS.map((_, i) => (
            <div key={i} className="h-1 rounded-full transition-all duration-300"
                 style={{
                   width: i === onboardingStep ? 20 : 8,
                   background: i === onboardingStep ? '#9FE1CB' : '#333',
                 }} />
          ))}
        </div>

        <div className="text-4xl mb-4">{step.emoji}</div>
        <h2 className="text-lg font-medium mb-2" style={{ color: '#E8E8E6' }}>{step.title}</h2>
        <p className="text-sm leading-relaxed mb-6" style={{ color: '#999' }}>{step.description}</p>

        <div className="flex gap-2 justify-center">
          <button onClick={dismissOnboarding}
                  className="px-4 py-2 rounded-xl text-sm transition-all active:scale-95"
                  style={{ color: '#666' }}>
            Skip
          </button>
          <button onClick={next}
                  className="px-6 py-2 rounded-xl text-sm font-medium transition-all active:scale-95"
                  style={{ background: 'rgba(159,225,203,0.15)', color: '#9FE1CB', border: '1px solid rgba(159,225,203,0.2)' }}>
            {isLast ? 'Got it!' : 'Next'}
          </button>
        </div>
      </div>
    </div>
  );
}
