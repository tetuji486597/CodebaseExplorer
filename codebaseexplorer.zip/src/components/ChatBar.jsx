import { useState, useRef, useEffect } from 'react';
import useStore from '../store/useStore';

export default function ChatBar() {
  const [input, setInput] = useState('');
  const [expanded, setExpanded] = useState(false);
  const [streamingText, setStreamingText] = useState('');
  const messagesEndRef = useRef(null);
  const {
    chatMessages, chatLoading, addChatMessage, setChatLoading,
    concepts, projectId, selectedNode, showInspector,
  } = useStore();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, streamingText]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim() || chatLoading) return;

    const userMsg = input.trim();
    addChatMessage({ role: 'user', content: userMsg });
    setInput('');
    setChatLoading(true);
    setExpanded(true);
    setStreamingText('');

    // If we have a projectId, use the real backend
    if (projectId) {
      try {
        const response = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: userMsg,
            projectId,
            selectedNode,
          }),
        });

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let accumulated = '';
        let buffer = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';

          for (const line of lines) {
            if (line.startsWith('data: ')) {
              try {
                const data = JSON.parse(line.slice(6));
                if (data.text) {
                  accumulated += data.text;
                  setStreamingText(accumulated);
                }
                if (data.done) {
                  addChatMessage({ role: 'assistant', content: accumulated });
                  setStreamingText('');
                  setChatLoading(false);
                  return;
                }
                if (data.error) {
                  addChatMessage({ role: 'assistant', content: `Error: ${data.error}` });
                  setStreamingText('');
                  setChatLoading(false);
                  return;
                }
              } catch {}
            }
          }
        }

        // If stream ended without explicit done
        if (accumulated) {
          addChatMessage({ role: 'assistant', content: accumulated });
        }
        setStreamingText('');
        setChatLoading(false);
      } catch (err) {
        addChatMessage({ role: 'assistant', content: `Failed to get response: ${err.message}` });
        setStreamingText('');
        setChatLoading(false);
      }
    } else {
      // Demo mode fallback
      setTimeout(() => {
        const responses = [
          `This codebase is organized around ${concepts.length} main concepts: ${concepts.slice(0, 4).map(c => `${c.emoji} ${c.name}`).join(', ')}. Each concept groups related files together.`,
          `Think of this app like a restaurant. Each concept is a different area — the kitchen, the dining room, the front desk — all working together.`,
        ];
        addChatMessage({
          role: 'assistant',
          content: responses[Math.floor(Math.random() * responses.length)],
        });
        setChatLoading(false);
      }, 800);
    }
  };

  // Parse [[concept:key]] and [[file:path]] references in messages
  const renderMessage = (content) => {
    const parts = content.split(/(\[\[(?:concept|file):[^\]]+\]\])/g);
    return parts.map((part, i) => {
      const conceptMatch = part.match(/\[\[concept:([^\]]+)\]\]/);
      const fileMatch = part.match(/\[\[file:([^\]]+)\]\]/);

      if (conceptMatch) {
        const key = conceptMatch[1];
        const concept = concepts.find(c => c.id === key);
        return (
          <button
            key={i}
            onClick={() => {
              useStore.getState().setSelectedNode({ type: 'concept', id: key });
              useStore.getState().setShowInspector(true);
            }}
            className="inline-flex items-center gap-1 px-1 rounded text-xs"
            style={{ background: 'rgba(159,225,203,0.1)', color: '#9FE1CB' }}
          >
            {concept?.emoji} {concept?.name || key}
          </button>
        );
      }

      if (fileMatch) {
        const path = fileMatch[1];
        return (
          <button
            key={i}
            onClick={() => {
              useStore.getState().setSelectedNode({ type: 'file', id: path });
              useStore.getState().setShowInspector(true);
            }}
            className="inline mono text-xs px-1 rounded"
            style={{ background: 'rgba(206,203,246,0.1)', color: '#CECBF6' }}
          >
            {path.split('/').pop()}
          </button>
        );
      }

      return <span key={i}>{part}</span>;
    });
  };

  return (
    <div className="absolute bottom-0 left-0 z-20"
         style={{ right: showInspector ? 'min(380px, 90vw)' : 0 }}>
      {/* Messages area (expandable) */}
      {expanded && (chatMessages.length > 0 || streamingText) && (
        <div className="mx-3 mb-1 rounded-t-xl overflow-hidden"
             style={{ background: '#1A1A18', border: '0.5px solid #333', borderBottom: 'none', maxHeight: '40vh' }}>
          <div className="flex items-center justify-between px-3 py-2"
               style={{ borderBottom: '0.5px solid #282826' }}>
            <span className="text-xs" style={{ color: '#888' }}>Chat</span>
            <button onClick={() => setExpanded(false)} className="text-xs" style={{ color: '#666' }}>
              Collapse
            </button>
          </div>
          <div className="overflow-auto p-3 space-y-2" style={{ maxHeight: '35vh' }}>
            {chatMessages.map((msg, i) => (
              <div key={i}
                   className={`text-sm p-2.5 rounded-lg leading-relaxed ${msg.role === 'user' ? 'ml-12' : 'mr-4'}`}
                   style={{
                     background: msg.role === 'user' ? 'rgba(159,225,203,0.08)' : '#131311',
                     color: msg.role === 'user' ? '#9FE1CB' : '#CCC',
                     border: '0.5px solid #282826',
                   }}>
                {msg.role === 'assistant' ? renderMessage(msg.content) : msg.content}
              </div>
            ))}
            {streamingText && (
              <div className="text-sm p-2.5 rounded-lg leading-relaxed mr-4"
                   style={{ background: '#131311', color: '#CCC', border: '0.5px solid #282826' }}>
                {renderMessage(streamingText)}
                <span className="inline-block w-1.5 h-3 ml-0.5 rounded-sm" style={{ background: '#9FE1CB', animation: 'processing-dot 1s infinite' }} />
              </div>
            )}
            {chatLoading && !streamingText && (
              <div className="flex gap-1 p-3">
                <div className="w-1.5 h-1.5 rounded-full" style={{ background: '#9FE1CB', animation: 'processing-dot 1.4s infinite 0s' }} />
                <div className="w-1.5 h-1.5 rounded-full" style={{ background: '#9FE1CB', animation: 'processing-dot 1.4s infinite 0.2s' }} />
                <div className="w-1.5 h-1.5 rounded-full" style={{ background: '#9FE1CB', animation: 'processing-dot 1.4s infinite 0.4s' }} />
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </div>
      )}

      {/* Input bar */}
      <div className="p-3">
        <form onSubmit={handleSubmit}>
          <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl transition-all"
               style={{ background: '#1A1A18', border: '0.5px solid #333' }}
               onClick={() => chatMessages.length > 0 && setExpanded(true)}>
            <span className="text-sm" style={{ color: '#555' }}>✨</span>
            <input
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              placeholder="Ask anything about this codebase..."
              className="flex-1 bg-transparent text-sm outline-none"
              style={{ color: '#E8E8E6' }}
            />
            {input.trim() && (
              <button type="submit"
                      className="px-2.5 py-1 rounded-lg text-xs font-medium transition-all active:scale-95"
                      style={{ background: 'rgba(159,225,203,0.15)', color: '#9FE1CB' }}>
                Send
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}
