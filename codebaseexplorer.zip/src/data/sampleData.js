export const CONCEPT_COLORS = {
  teal: { fill: '#04342C', stroke: '#9FE1CB', text: '#9FE1CB', fillLight: '#9FE1CB', strokeLight: '#0F6E56', textLight: '#04342C' },
  purple: { fill: '#26215C', stroke: '#CECBF6', text: '#CECBF6', fillLight: '#CECBF6', strokeLight: '#534AB7', textLight: '#26215C' },
  coral: { fill: '#4A1B0C', stroke: '#F5C4B3', text: '#F5C4B3', fillLight: '#F5C4B3', strokeLight: '#993C1D', textLight: '#4A1B0C' },
  blue: { fill: '#042C53', stroke: '#B5D4F4', text: '#B5D4F4', fillLight: '#B5D4F4', strokeLight: '#185FA5', textLight: '#042C53' },
  amber: { fill: '#412402', stroke: '#FAC775', text: '#FAC775', fillLight: '#FAC775', strokeLight: '#BA7517', textLight: '#412402' },
  pink: { fill: '#4B1528', stroke: '#F4C0D1', text: '#F4C0D1', fillLight: '#F4C0D1', strokeLight: '#993556', textLight: '#4B1528' },
  green: { fill: '#173404', stroke: '#C0DD97', text: '#C0DD97', fillLight: '#C0DD97', strokeLight: '#3B6D11', textLight: '#173404' },
  gray: { fill: '#2C2C2A', stroke: '#D3D1C7', text: '#D3D1C7', fillLight: '#D3D1C7', strokeLight: '#5F5E5A', textLight: '#2C2C2A' },
};

export const COLOR_NAMES = Object.keys(CONCEPT_COLORS);

export const sampleConcepts = [
  {
    id: 'auth',
    name: 'Sign In / Sign Up',
    emoji: '🔑',
    color: 'teal',
    description: 'Handles user registration, login, and authentication. Manages secure user sessions and password verification.',
  },
  {
    id: 'feed',
    name: 'Home Feed',
    emoji: '🏠',
    color: 'purple',
    description: 'Displays a personalized stream of posts from users you follow. Loads and refreshes content as you scroll.',
  },
  {
    id: 'posts',
    name: 'Posts',
    emoji: '📸',
    color: 'coral',
    description: 'Manages creating, editing, and deleting posts. Handles post metadata like captions, hashtags, and timestamps.',
  },
  {
    id: 'profiles',
    name: 'User Profiles',
    emoji: '👤',
    color: 'blue',
    description: 'Shows user information, bio, profile picture, and follower lists. Allows users to edit their own profile.',
  },
  {
    id: 'notifications',
    name: 'Notifications',
    emoji: '🔔',
    color: 'amber',
    description: 'Alerts users about likes, comments, follows, and other interactions. Manages notification preferences and delivery.',
  },
  {
    id: 'media',
    name: 'Media Storage',
    emoji: '🗂️',
    color: 'pink',
    description: 'Stores and serves images and videos. Handles file uploads, compression, and efficient retrieval.',
  },
  {
    id: 'search',
    name: 'Search',
    emoji: '🔍',
    color: 'green',
    description: 'Allows users to find posts, users, and hashtags. Provides fast search results with filtering options.',
  },
  {
    id: 'database',
    name: 'Database',
    emoji: '🗄️',
    color: 'gray',
    description: 'The core data storage for all application information. Manages users, posts, relationships, and metrics.',
  },
  {
    id: 'email',
    name: 'Email',
    emoji: '✉️',
    color: 'teal',
    description: 'Sends transactional emails to users for verification, password resets, and activity notifications.',
  },
];

export const sampleFiles = [
  // Sign In / Sign Up
  {
    id: 'file-1',
    name: 'auth.controller.ts',
    conceptId: 'auth',
    description: 'Handles HTTP requests for user authentication endpoints. Processes login and registration requests.',
    exports: ['AuthController', 'loginRoute', 'registerRoute', 'logoutRoute'],
    codeSnippet: `import { Router, Request, Response } from 'express';
import { AuthService } from './auth.service';
import { validateEmail, hashPassword } from '../utils/validators';

const router = Router();
const authService = new AuthService();

router.post('/login', async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;
    const user = await authService.authenticateUser(email, password);
    req.session.userId = user.id;
    res.json({ success: true, user });
  } catch (error) {
    res.status(401).json({ error: 'Invalid credentials' });
  }
});

router.post('/register', async (req: Request, res: Response) => {
  const { email, username, password } = req.body;
  const hashedPassword = hashPassword(password);
  const user = await authService.createUser(email, username, hashedPassword);
  res.status(201).json({ success: true, user });
});

export default router;`,
  },
  {
    id: 'file-2',
    name: 'auth.service.ts',
    conceptId: 'auth',
    description: 'Business logic for authentication. Verifies credentials and manages user sessions.',
    exports: ['AuthService', 'authenticateUser', 'createUser', 'verifyToken'],
    codeSnippet: `import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { UserRepository } from '../repositories/user.repository';

export class AuthService {
  private userRepo = new UserRepository();
  private jwtSecret = process.env.JWT_SECRET;

  async authenticateUser(email: string, password: string) {
    const user = await this.userRepo.findByEmail(email);
    if (!user) throw new Error('User not found');

    const isValid = await bcrypt.compare(password, user.passwordHash);
    if (!isValid) throw new Error('Invalid password');

    const token = jwt.sign({ userId: user.id }, this.jwtSecret, { expiresIn: '7d' });
    return { ...user, token };
  }

  async createUser(email: string, username: string, passwordHash: string) {
    const existingUser = await this.userRepo.findByEmail(email);
    if (existingUser) throw new Error('User already exists');

    return this.userRepo.create({ email, username, passwordHash });
  }

  verifyToken(token: string) {
    return jwt.verify(token, this.jwtSecret);
  }
}`,
  },
  {
    id: 'file-3',
    name: 'login.screen.tsx',
    conceptId: 'auth',
    description: 'React component displaying the login form interface.',
    exports: ['LoginScreen', 'useLoginForm'],
    codeSnippet: `import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { TextInput, Button, ErrorMessage } from '../components/common';
import styles from './login.module.css';

export const LoginScreen: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { login, isLoading } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await login(email, password);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className={styles.container}>
      <h1>Welcome Back</h1>
      <form onSubmit={handleSubmit}>
        <TextInput label="Email" value={email} onChange={setEmail} />
        <TextInput label="Password" type="password" value={password} onChange={setPassword} />
        {error && <ErrorMessage message={error} />}
        <Button type="submit" disabled={isLoading}>Login</Button>
      </form>
    </div>
  );
};`,
  },
  {
    id: 'file-4',
    name: 'register.screen.tsx',
    conceptId: 'auth',
    description: 'React component for user registration interface with form validation.',
    exports: ['RegisterScreen'],
    codeSnippet: `import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { validatePassword, validateEmail } from '../utils/validators';
import { TextInput, Button, CheckBox } from '../components/common';

export const RegisterScreen: React.FC = () => {
  const [formData, setFormData] = useState({ email: '', username: '', password: '', confirmPassword: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const { register, isLoading } = useAuth();

  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    if (!validateEmail(formData.email)) newErrors.email = 'Invalid email';
    if (formData.password.length < 8) newErrors.password = 'Password must be 8+ characters';
    if (formData.password !== formData.confirmPassword) newErrors.confirmPassword = 'Passwords must match';
    return newErrors;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }
    await register(formData);
  };

  return (
    <form onSubmit={handleSubmit}>
      <TextInput label="Email" value={formData.email} />
      <TextInput label="Username" value={formData.username} />
      <TextInput label="Password" type="password" value={formData.password} />
      <Button type="submit">Create Account</Button>
    </form>
  );
};`,
  },

  // Home Feed
  {
    id: 'file-5',
    name: 'feed.screen.tsx',
    conceptId: 'feed',
    description: 'Main feed screen component. Displays scrollable list of posts from followed users.',
    exports: ['FeedScreen', 'InfiniteFeed'],
    codeSnippet: `import React, { useEffect, useState } from 'react';
import { useInfiniteScroll } from '../hooks/useInfiniteScroll';
import { useFeed } from '../hooks/useFeed';
import { FeedItem } from './feedItem.component';
import { LoadingSpinner } from '../components/common';
import styles from './feed.module.css';

export const FeedScreen: React.FC = () => {
  const { posts, isLoading, hasMore, loadMore } = useFeed();
  const { setObserverTarget } = useInfiniteScroll(() => loadMore());

  return (
    <div className={styles.feedContainer}>
      <header className={styles.header}>
        <h1>Instagram</h1>
      </header>
      <div className={styles.postsContainer}>
        {posts.map(post => (
          <FeedItem key={post.id} post={post} />
        ))}
      </div>
      {isLoading && <LoadingSpinner />}
      <div ref={setObserverTarget} className={styles.loadTrigger} />
    </div>
  );
};`,
  },
  {
    id: 'file-6',
    name: 'feed.service.ts',
    conceptId: 'feed',
    description: 'Service layer for feed data operations. Fetches posts and manages pagination.',
    exports: ['FeedService', 'getFollowingPosts', 'getPaginatedFeed', 'prefetchFeed'],
    codeSnippet: `import { HttpClient } from '../http/client';
import { Post } from '../models/post.model';

export class FeedService {
  private readonly baseUrl = '/api/feed';
  private pageSize = 10;

  async getFollowingPosts(userId: string, page: number = 1) {
    const response = await HttpClient.get<Post[]>(
      \`\${this.baseUrl}/following?userId=\${userId}&page=\${page}&limit=\${this.pageSize}\`
    );
    return response.data;
  }

  async getPaginatedFeed(userId: string, pageToken?: string) {
    const params = new URLSearchParams({ userId });
    if (pageToken) params.append('pageToken', pageToken);

    const response = await HttpClient.get(
      \`\${this.baseUrl}?\${params.toString()}\`
    );
    return { posts: response.data.posts, nextPageToken: response.data.nextPageToken };
  }

  async prefetchFeed(userId: string) {
    return this.getFollowingPosts(userId, 1);
  }

  async refreshFeed(userId: string) {
    return this.getFollowingPosts(userId, 1);
  }
}`,
  },
  {
    id: 'file-7',
    name: 'feedItem.component.tsx',
    conceptId: 'feed',
    description: 'Individual feed post component. Displays post content, engagement metrics, and interactions.',
    exports: ['FeedItem', 'PostActions'],
    codeSnippet: `import React, { useState } from 'react';
import { Post } from '../models/post.model';
import { LikeButton, CommentButton, ShareButton } from '../components/interactions';
import { Avatar } from '../components/avatar';
import styles from './feedItem.module.css';

interface FeedItemProps {
  post: Post;
}

export const FeedItem: React.FC<FeedItemProps> = ({ post }) => {
  const [liked, setLiked] = useState(post.isLiked);
  const [likeCount, setLikeCount] = useState(post.likeCount);

  const handleLike = async () => {
    setLiked(!liked);
    setLikeCount(liked ? likeCount - 1 : likeCount + 1);
  };

  return (
    <div className={styles.feedItem}>
      <div className={styles.header}>
        <Avatar src={post.author.avatarUrl} />
        <span className={styles.username}>{post.author.username}</span>
      </div>
      <img src={post.imageUrl} alt={post.caption} className={styles.image} />
      <div className={styles.actions}>
        <LikeButton liked={liked} onLike={handleLike} />
        <CommentButton count={post.commentCount} />
        <ShareButton />
      </div>
      <p className={styles.caption}>{post.caption}</p>
    </div>
  );
};`,
  },
  {
    id: 'file-8',
    name: 'feed.hooks.ts',
    conceptId: 'feed',
    description: 'Custom React hooks for feed functionality. Manages feed state and data fetching.',
    exports: ['useFeed', 'useInfiniteFeed', 'useFeedRefresh'],
    codeSnippet: `import { useState, useEffect, useCallback } from 'react';
import { FeedService } from './feed.service';
import { Post } from '../models/post.model';

const feedService = new FeedService();

export const useFeed = (userId: string) => {
  const [posts, setPosts] = useState<Post[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [pageToken, setPageToken] = useState<string | undefined>();

  useEffect(() => {
    loadInitialFeed();
  }, [userId]);

  const loadInitialFeed = async () => {
    setIsLoading(true);
    const initialPosts = await feedService.getFollowingPosts(userId);
    setPosts(initialPosts);
    setIsLoading(false);
  };

  const loadMore = useCallback(async () => {
    const { posts: newPosts, nextPageToken } = await feedService.getPaginatedFeed(userId, pageToken);
    setPosts(prev => [...prev, ...newPosts]);
    setPageToken(nextPageToken);
    setHasMore(!!nextPageToken);
  }, [userId, pageToken]);

  return { posts, isLoading, hasMore, loadMore };
};`,
  },

  // Posts
  {
    id: 'file-9',
    name: 'post.model.ts',
    conceptId: 'posts',
    description: 'TypeScript models for post data structures. Defines interfaces for posts and related entities.',
    exports: ['Post', 'PostInput', 'Comment', 'PostMetadata'],
    codeSnippet: `export interface Post {
  id: string;
  authorId: string;
  author: {
    id: string;
    username: string;
    avatarUrl: string;
  };
  caption: string;
  imageUrl: string;
  imageUrls?: string[];
  createdAt: Date;
  updatedAt: Date;
  likeCount: number;
  commentCount: number;
  shareCount: number;
  isLiked?: boolean;
  hashtags: string[];
  location?: string;
  comments?: Comment[];
}

export interface PostInput {
  caption: string;
  imageUrls: string[];
  hashtags?: string[];
  location?: string;
}

export interface Comment {
  id: string;
  authorId: string;
  author: { username: string; avatarUrl: string };
  text: string;
  createdAt: Date;
  likeCount: number;
}

export interface PostMetadata {
  viewCount: number;
  savesCount: number;
  sharesCount: number;
}`,
  },
  {
    id: 'file-10',
    name: 'post.service.ts',
    conceptId: 'posts',
    description: 'Service for post CRUD operations. Handles creating, updating, and deleting posts.',
    exports: ['PostService', 'createPost', 'updatePost', 'deletePost', 'getPost'],
    codeSnippet: `import { HttpClient } from '../http/client';
import { Post, PostInput } from './post.model';
import { MediaService } from '../media/media.service';

export class PostService {
  private baseUrl = '/api/posts';
  private mediaService = new MediaService();

  async createPost(userId: string, postInput: PostInput): Promise<Post> {
    const response = await HttpClient.post(\`\${this.baseUrl}\`, {
      ...postInput,
      authorId: userId,
      createdAt: new Date(),
    });
    return response.data;
  }

  async updatePost(postId: string, updates: Partial<PostInput>): Promise<Post> {
    const response = await HttpClient.put(\`\${this.baseUrl}/\${postId}\`, updates);
    return response.data;
  }

  async deletePost(postId: string): Promise<void> {
    await HttpClient.delete(\`\${this.baseUrl}/\${postId}\`);
  }

  async getPost(postId: string): Promise<Post> {
    const response = await HttpClient.get(\`\${this.baseUrl}/\${postId}\`);
    return response.data;
  }

  async likePost(postId: string, userId: string): Promise<void> {
    await HttpClient.post(\`\${this.baseUrl}/\${postId}/like\`, { userId });
  }

  async unlikePost(postId: string, userId: string): Promise<void> {
    await HttpClient.delete(\`\${this.baseUrl}/\${postId}/like?userId=\${userId}\`);
  }
}`,
  },
  {
    id: 'file-11',
    name: 'createPost.screen.tsx',
    conceptId: 'posts',
    description: 'Screen for creating new posts. Allows caption entry, image upload, and hashtag addition.',
    exports: ['CreatePostScreen', 'PostEditor'],
    codeSnippet: `import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { PostService } from './post.service';
import { ImageUploader } from '../components/imageUploader';
import { TextInput, Button } from '../components/common';
import styles from './createPost.module.css';

export const CreatePostScreen: React.FC = () => {
  const { user } = useAuth();
  const [caption, setCaption] = useState('');
  const [hashtags, setHashtags] = useState<string[]>([]);
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [isPosting, setIsPosting] = useState(false);
  const postService = new PostService();

  const handlePostSubmit = async () => {
    if (!caption || imageUrls.length === 0) return;

    setIsPosting(true);
    try {
      await postService.createPost(user.id, {
        caption,
        imageUrls,
        hashtags,
      });
      setCaption('');
      setHashtags([]);
      setImageUrls([]);
    } finally {
      setIsPosting(false);
    }
  };

  return (
    <div className={styles.container}>
      <h2>Create New Post</h2>
      <ImageUploader onUpload={setImageUrls} />
      <TextInput label="Caption" value={caption} onChange={setCaption} multiline />
      <TextInput label="Add hashtags (comma separated)" onChange={(val) => setHashtags(val.split(','))} />
      <Button onClick={handlePostSubmit} disabled={isPosting}>Post</Button>
    </div>
  );
};`,
  },
  {
    id: 'file-12',
    name: 'postCard.component.tsx',
    conceptId: 'posts',
    description: 'Reusable post card component. Displays post information in compact form.',
    exports: ['PostCard', 'PostCardSkeleton'],
    codeSnippet: `import React from 'react';
import { Post } from './post.model';
import { Avatar } from '../components/avatar';
import { LikeButton, CommentButton } from '../components/interactions';
import styles from './postCard.module.css';

interface PostCardProps {
  post: Post;
  onClick?: () => void;
}

export const PostCard: React.FC<PostCardProps> = ({ post, onClick }) => {
  return (
    <div className={styles.card} onClick={onClick}>
      <div className={styles.cardHeader}>
        <Avatar src={post.author.avatarUrl} size="small" />
        <div className={styles.authorInfo}>
          <p className={styles.username}>{post.author.username}</p>
          <p className={styles.timestamp}>{formatTime(post.createdAt)}</p>
        </div>
      </div>
      <img src={post.imageUrl} alt="" className={styles.image} />
      <div className={styles.footer}>
        <span>{post.likeCount} likes</span>
        <span>{post.commentCount} comments</span>
      </div>
    </div>
  );
};

const formatTime = (date: Date) => {
  const now = new Date();
  const diffMs = now.getTime() - new Date(date).getTime();
  const diffMins = Math.floor(diffMs / 60000);
  if (diffMins < 60) return \`\${diffMins}m ago\`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return \`\${diffHours}h ago\`;
  return \`\${Math.floor(diffHours / 24)}d ago\`;
};`,
  },
  {
    id: 'file-13',
    name: 'comments.component.tsx',
    conceptId: 'posts',
    description: 'Component for displaying and managing post comments. Allows viewing and adding comments.',
    exports: ['CommentsSection', 'CommentInput', 'CommentThread'],
    codeSnippet: `import React, { useState } from 'react';
import { Comment, Post } from './post.model';
import { Avatar } from '../components/avatar';
import { TextInput, Button } from '../components/common';
import styles from './comments.module.css';

interface CommentsSectionProps {
  post: Post;
  onAddComment: (text: string) => Promise<void>;
}

export const CommentsSection: React.FC<CommentsSectionProps> = ({ post, onAddComment }) => {
  const [newComment, setNewComment] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async () => {
    if (!newComment.trim()) return;
    setIsLoading(true);
    try {
      await onAddComment(newComment);
      setNewComment('');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={styles.commentsSection}>
      <h3>Comments ({post.commentCount})</h3>
      <div className={styles.commentsList}>
        {post.comments?.map(comment => (
          <div key={comment.id} className={styles.comment}>
            <Avatar src={comment.author.avatarUrl} size="small" />
            <div className={styles.commentContent}>
              <strong>{comment.author.username}</strong>
              <p>{comment.text}</p>
            </div>
          </div>
        ))}
      </div>
      <div className={styles.commentInput}>
        <TextInput value={newComment} onChange={setNewComment} placeholder="Add a comment..." />
        <Button onClick={handleSubmit} disabled={isLoading}>Post</Button>
      </div>
    </div>
  );
};`,
  },

  // User Profiles
  {
    id: 'file-14',
    name: 'profile.screen.tsx',
    conceptId: 'profiles',
    description: 'User profile display screen. Shows user info, bio, posts grid, and follower stats.',
    exports: ['ProfileScreen', 'ProfileHeader'],
    codeSnippet: `import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { ProfileService } from './profile.service';
import { Avatar } from '../components/avatar';
import { Button } from '../components/common';
import styles from './profile.module.css';

interface UserProfile {
  id: string;
  username: string;
  displayName: string;
  bio: string;
  avatarUrl: string;
  followerCount: number;
  followingCount: number;
  postsCount: number;
  isFollowing?: boolean;
}

export const ProfileScreen: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const profileService = new ProfileService();

  useEffect(() => {
    const loadProfile = async () => {
      const data = await profileService.getUserProfile(userId);
      setProfile(data);
      setIsLoading(false);
    };
    loadProfile();
  }, [userId]);

  if (isLoading || !profile) return <div>Loading...</div>;

  return (
    <div className={styles.profileContainer}>
      <div className={styles.header}>
        <Avatar src={profile.avatarUrl} size="large" />
        <div className={styles.info}>
          <h1>{profile.displayName}</h1>
          <p className={styles.username}>@{profile.username}</p>
          <p className={styles.bio}>{profile.bio}</p>
        </div>
      </div>
      <div className={styles.stats}>
        <div><strong>{profile.postsCount}</strong> Posts</div>
        <div><strong>{profile.followerCount}</strong> Followers</div>
        <div><strong>{profile.followingCount}</strong> Following</div>
      </div>
    </div>
  );
};`,
  },
  {
    id: 'file-15',
    name: 'profile.service.ts',
    conceptId: 'profiles',
    description: 'Service for profile-related API calls. Fetches and updates user profile data.',
    exports: ['ProfileService', 'getUserProfile', 'updateProfile', 'followUser'],
    codeSnippet: `import { HttpClient } from '../http/client';

export interface UserProfile {
  id: string;
  username: string;
  displayName: string;
  bio: string;
  avatarUrl: string;
  followerCount: number;
  followingCount: number;
  postsCount: number;
}

export class ProfileService {
  private baseUrl = '/api/users';

  async getUserProfile(userId: string): Promise<UserProfile> {
    const response = await HttpClient.get(\`\${this.baseUrl}/\${userId}\`);
    return response.data;
  }

  async updateProfile(userId: string, updates: Partial<UserProfile>): Promise<UserProfile> {
    const response = await HttpClient.put(\`\${this.baseUrl}/\${userId}\`, updates);
    return response.data;
  }

  async followUser(userId: string, targetUserId: string): Promise<void> {
    await HttpClient.post(\`\${this.baseUrl}/\${userId}/follow/\${targetUserId}\`, {});
  }

  async unfollowUser(userId: string, targetUserId: string): Promise<void> {
    await HttpClient.delete(\`\${this.baseUrl}/\${userId}/follow/\${targetUserId}\`);
  }

  async getUserPosts(userId: string, page: number = 1) {
    const response = await HttpClient.get(\`\${this.baseUrl}/\${userId}/posts?page=\${page}\`);
    return response.data;
  }
}`,
  },
  {
    id: 'file-16',
    name: 'editProfile.screen.tsx',
    conceptId: 'profiles',
    description: 'Screen for editing user profile information. Allows updating bio, avatar, and display name.',
    exports: ['EditProfileScreen'],
    codeSnippet: `import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { ProfileService } from './profile.service';
import { TextInput, Button, ImageUploader } from '../components/common';
import styles from './editProfile.module.css';

export const EditProfileScreen: React.FC = () => {
  const { user, updateUser } = useAuth();
  const [displayName, setDisplayName] = useState(user.displayName);
  const [bio, setBio] = useState(user.bio);
  const [avatarUrl, setAvatarUrl] = useState(user.avatarUrl);
  const [isSaving, setIsSaving] = useState(false);
  const profileService = new ProfileService();

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const updated = await profileService.updateProfile(user.id, {
        displayName,
        bio,
        avatarUrl,
      });
      updateUser(updated);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className={styles.container}>
      <h2>Edit Profile</h2>
      <ImageUploader onUpload={(urls) => setAvatarUrl(urls[0])} singleImage />
      <TextInput label="Display Name" value={displayName} onChange={setDisplayName} />
      <TextInput label="Bio" value={bio} onChange={setBio} multiline rows={4} />
      <Button onClick={handleSave} disabled={isSaving}>Save Changes</Button>
    </div>
  );
};`,
  },

  // Notifications
  {
    id: 'file-17',
    name: 'notifications.screen.tsx',
    conceptId: 'notifications',
    description: 'Notifications feed screen. Displays all user notifications with timestamps and actions.',
    exports: ['NotificationsScreen', 'NotificationsList'],
    codeSnippet: `import React, { useEffect, useState } from 'react';
import { useAuth } from '../hooks/useAuth';
import { NotificationService } from './notification.service';
import { Avatar } from '../components/avatar';
import styles from './notifications.module.css';

interface Notification {
  id: string;
  type: 'like' | 'comment' | 'follow' | 'mention';
  actorUsername: string;
  actorAvatarUrl: string;
  targetId: string;
  message: string;
  createdAt: Date;
  isRead: boolean;
}

export const NotificationsScreen: React.FC = () => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const notificationService = new NotificationService();

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = async () => {
    const data = await notificationService.getNotifications(user.id);
    setNotifications(data);
    setIsLoading(false);
  };

  return (
    <div className={styles.container}>
      <h1>Notifications</h1>
      <div className={styles.notificationsList}>
        {notifications.map(notification => (
          <div key={notification.id} className={styles.notification}>
            <Avatar src={notification.actorAvatarUrl} size="small" />
            <div className={styles.content}>
              <p><strong>{notification.actorUsername}</strong> {notification.message}</p>
              <span className={styles.time}>{formatTime(notification.createdAt)}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

const formatTime = (date: Date) => {
  const now = new Date();
  const diffMs = now.getTime() - new Date(date).getTime();
  const diffMins = Math.floor(diffMs / 60000);
  if (diffMins < 60) return \`\${diffMins}m\`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return \`\${diffHours}h\`;
  return \`\${Math.floor(diffHours / 24)}d\`;
};`,
  },
  {
    id: 'file-18',
    name: 'notification.service.ts',
    conceptId: 'notifications',
    description: 'Service for notification management. Fetches, marks as read, and manages notification preferences.',
    exports: ['NotificationService', 'getNotifications', 'markAsRead', 'deleteNotification'],
    codeSnippet: `import { HttpClient } from '../http/client';

export interface Notification {
  id: string;
  userId: string;
  type: string;
  actorId: string;
  targetId: string;
  message: string;
  createdAt: Date;
  isRead: boolean;
}

export class NotificationService {
  private baseUrl = '/api/notifications';

  async getNotifications(userId: string) {
    const response = await HttpClient.get(\`\${this.baseUrl}?userId=\${userId}\`);
    return response.data;
  }

  async markAsRead(notificationId: string): Promise<void> {
    await HttpClient.put(\`\${this.baseUrl}/\${notificationId}\`, { isRead: true });
  }

  async deleteNotification(notificationId: string): Promise<void> {
    await HttpClient.delete(\`\${this.baseUrl}/\${notificationId}\`);
  }

  async getUnreadCount(userId: string): Promise<number> {
    const response = await HttpClient.get(\`\${this.baseUrl}/unread-count?userId=\${userId}\`);
    return response.data.count;
  }

  async markAllAsRead(userId: string): Promise<void> {
    await HttpClient.put(\`\${this.baseUrl}/mark-all-read\`, { userId });
  }

  subscribeToNotifications(userId: string, callback: (notification: Notification) => void) {
    const eventSource = new EventSource(\`\${this.baseUrl}/subscribe?userId=\${userId}\`);
    eventSource.onmessage = (event) => callback(JSON.parse(event.data));
    return () => eventSource.close();
  }
}`,
  },
  {
    id: 'file-19',
    name: 'pushNotification.handler.ts',
    conceptId: 'notifications',
    description: 'Handles push notifications and WebSocket events. Manages real-time notification delivery.',
    exports: ['PushNotificationHandler', 'subscribeToPushNotifications', 'sendPushNotification'],
    codeSnippet: `import { WebSocketClient } from '../websocket/client';
import { NotificationService } from './notification.service';

export class PushNotificationHandler {
  private wsClient: WebSocketClient;
  private notificationService: NotificationService;

  constructor(userId: string) {
    this.notificationService = new NotificationService();
    this.wsClient = new WebSocketClient(\`wss://api.example.com/ws?userId=\${userId}\`);
    this.setupListeners();
  }

  private setupListeners() {
    this.wsClient.on('notification', (data) => {
      this.handleIncomingNotification(data);
    });

    this.wsClient.on('like', (data) => {
      this.showDesktopNotification(\`\${data.actor} liked your post\`);
    });

    this.wsClient.on('comment', (data) => {
      this.showDesktopNotification(\`\${data.actor} commented on your post\`);
    });

    this.wsClient.on('follow', (data) => {
      this.showDesktopNotification(\`\${data.actor} started following you\`);
    });
  }

  private handleIncomingNotification(notification: any) {
    if (Notification.permission === 'granted') {
      new Notification(notification.title, {
        body: notification.message,
        icon: notification.icon,
      });
    }
  }

  private showDesktopNotification(message: string) {
    if (Notification.permission === 'granted') {
      new Notification('Instagram', { body: message });
    }
  }

  public async requestPermission() {
    if ('Notification' in window) {
      return Notification.requestPermission();
    }
  }

  public disconnect() {
    this.wsClient.disconnect();
  }
}`,
  },

  // Media Storage
  {
    id: 'file-20',
    name: 'media.service.ts',
    conceptId: 'media',
    description: 'Service for media upload and retrieval. Handles image and video file operations.',
    exports: ['MediaService', 'uploadImage', 'uploadVideo', 'deleteMedia', 'generateThumbnail'],
    codeSnippet: `import { HttpClient } from '../http/client';

export interface MediaUploadResponse {
  id: string;
  url: string;
  thumbnailUrl?: string;
  size: number;
  type: 'image' | 'video';
}

export class MediaService {
  private baseUrl = '/api/media';

  async uploadImage(file: File, userId: string): Promise<MediaUploadResponse> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('userId', userId);

    return HttpClient.post(\`\${this.baseUrl}/upload\`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  }

  async uploadVideo(file: File, userId: string, thumbnail: File): Promise<MediaUploadResponse> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('thumbnail', thumbnail);
    formData.append('userId', userId);

    return HttpClient.post(\`\${this.baseUrl}/upload/video\`, formData);
  }

  async deleteMedia(mediaId: string): Promise<void> {
    await HttpClient.delete(\`\${this.baseUrl}/\${mediaId}\`);
  }

  async generateThumbnail(mediaId: string): Promise<string> {
    const response = await HttpClient.post(\`\${this.baseUrl}/\${mediaId}/thumbnail\`, {});
    return response.data.thumbnailUrl;
  }

  async optimizeImage(mediaId: string, size: 'small' | 'medium' | 'large'): Promise<string> {
    const response = await HttpClient.get(\`\${this.baseUrl}/\${mediaId}/optimize?size=\${size}\`);
    return response.data.url;
  }
}`,
  },
  {
    id: 'file-21',
    name: 'imageUploader.component.tsx',
    conceptId: 'media',
    description: 'React component for image upload. Provides drag-drop and file selection interface.',
    exports: ['ImageUploader', 'useImageUpload'],
    codeSnippet: `import React, { useState, useRef } from 'react';
import { MediaService } from '../media/media.service';
import styles from './imageUploader.module.css';

interface ImageUploaderProps {
  onUpload: (urls: string[]) => void;
  singleImage?: boolean;
  maxFiles?: number;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({
  onUpload,
  singleImage = false,
  maxFiles = 10,
}) => {
  const [files, setFiles] = useState<File[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaService = new MediaService();

  const handleFilesSelected = async (selectedFiles: FileList) => {
    const newFiles = Array.from(selectedFiles);
    if (singleImage) {
      setFiles([newFiles[0]]);
    } else {
      setFiles(prev => [...prev, ...newFiles].slice(0, maxFiles));
    }
  };

  const handleUpload = async () => {
    setIsUploading(true);
    try {
      const uploadedUrls = await Promise.all(
        files.map(file => mediaService.uploadImage(file, localStorage.getItem('userId')!))
      );
      onUpload(uploadedUrls.map(r => r.url));
      setFiles([]);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div
      className={styles.uploader}
      onDrop={(e) => { e.preventDefault(); handleFilesSelected(e.dataTransfer.files); }}
      onDragOver={(e) => e.preventDefault()}
    >
      <input
        ref={fileInputRef}
        type="file"
        multiple={!singleImage}
        accept="image/*"
        onChange={(e) => handleFilesSelected(e.target.files!)}
      />
      <p>Drag and drop images here or click to select</p>
      {files.length > 0 && <button onClick={handleUpload} disabled={isUploading}>Upload</button>}
    </div>
  );
};`,
  },
  {
    id: 'file-22',
    name: 'mediaCache.ts',
    conceptId: 'media',
    description: 'In-memory cache for media files and metadata. Reduces redundant network requests.',
    exports: ['MediaCache', 'getCachedMedia', 'cacheMedia', 'clearCache'],
    codeSnippet: `interface CachedMedia {
  id: string;
  url: string;
  thumbnailUrl?: string;
  timestamp: number;
  accessCount: number;
}

export class MediaCache {
  private static instance: MediaCache;
  private cache = new Map<string, CachedMedia>();
  private readonly maxSize = 100;
  private readonly ttl = 3600000; // 1 hour

  private constructor() {}

  static getInstance(): MediaCache {
    if (!MediaCache.instance) {
      MediaCache.instance = new MediaCache();
    }
    return MediaCache.instance;
  }

  get(mediaId: string): CachedMedia | null {
    const item = this.cache.get(mediaId);
    if (!item) return null;

    const age = Date.now() - item.timestamp;
    if (age > this.ttl) {
      this.cache.delete(mediaId);
      return null;
    }

    item.accessCount++;
    return item;
  }

  set(mediaId: string, data: CachedMedia): void {
    if (this.cache.size >= this.maxSize) {
      const oldestKey = Array.from(this.cache.entries())
        .sort((a, b) => a[1].timestamp - b[1].timestamp)[0][0];
      this.cache.delete(oldestKey);
    }
    this.cache.set(mediaId, { ...data, timestamp: Date.now() });
  }

  clear(): void {
    this.cache.clear();
  }

  getStats() {
    return {
      size: this.cache.size,
      items: Array.from(this.cache.values()),
    };
  }
}`,
  },

  // Search
  {
    id: 'file-23',
    name: 'search.screen.tsx',
    conceptId: 'search',
    description: 'Search interface screen. Allows users to search for posts, users, and hashtags.',
    exports: ['SearchScreen', 'SearchResults'],
    codeSnippet: `import React, { useState, useEffect } from 'react';
import { SearchService } from './search.service';
import { TextInput, LoadingSpinner } from '../components/common';
import styles from './search.module.css';

interface SearchResult {
  type: 'post' | 'user' | 'hashtag';
  id: string;
  title: string;
  subtitle?: string;
  imageUrl?: string;
}

export const SearchScreen: React.FC = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'posts' | 'users' | 'hashtags'>('all');
  const searchService = new SearchService();

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      return;
    }

    const timer = setTimeout(async () => {
      setIsLoading(true);
      const searchResults = await searchService.search(query, activeTab);
      setResults(searchResults);
      setIsLoading(false);
    }, 300);

    return () => clearTimeout(timer);
  }, [query, activeTab]);

  return (
    <div className={styles.container}>
      <TextInput
        placeholder="Search posts, people, hashtags..."
        value={query}
        onChange={setQuery}
        autoFocus
      />
      <div className={styles.tabs}>
        {['all', 'posts', 'users', 'hashtags'].map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab as any)} className={activeTab === tab ? styles.active : ''}>
            {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>
      {isLoading ? <LoadingSpinner /> : <SearchResults results={results} />}
    </div>
  );
};`,
  },
  {
    id: 'file-24',
    name: 'search.service.ts',
    conceptId: 'search',
    description: 'Search service with filtering and ranking. Provides fast search across posts and users.',
    exports: ['SearchService', 'search', 'searchHashtags', 'searchUsers'],
    codeSnippet: `import { HttpClient } from '../http/client';

export interface SearchQuery {
  text: string;
  type?: 'posts' | 'users' | 'hashtags';
  limit?: number;
  offset?: number;
}

export class SearchService {
  private baseUrl = '/api/search';
  private recentSearches: string[] = [];

  async search(query: string, type: string = 'all') {
    const response = await HttpClient.get(\`\${this.baseUrl}\`, {
      params: { q: query, type, limit: 20 },
    });
    this.addRecentSearch(query);
    return response.data.results;
  }

  async searchUsers(query: string) {
    const response = await HttpClient.get(\`\${this.baseUrl}/users\`, {
      params: { q: query },
    });
    return response.data;
  }

  async searchPosts(query: string) {
    const response = await HttpClient.get(\`\${this.baseUrl}/posts\`, {
      params: { q: query },
    });
    return response.data;
  }

  async searchHashtags(query: string) {
    const response = await HttpClient.get(\`\${this.baseUrl}/hashtags\`, {
      params: { q: query },
    });
    return response.data;
  }

  addRecentSearch(query: string) {
    this.recentSearches = [query, ...this.recentSearches.filter(s => s !== query)].slice(0, 10);
    localStorage.setItem('recentSearches', JSON.stringify(this.recentSearches));
  }

  getRecentSearches() {
    return JSON.parse(localStorage.getItem('recentSearches') || '[]');
  }
}`,
  },
  {
    id: 'file-25',
    name: 'searchResults.component.tsx',
    conceptId: 'search',
    description: 'Displays search results in organized sections. Groups results by type.',
    exports: ['SearchResults', 'ResultItem'],
    codeSnippet: `import React from 'react';
import { Avatar } from '../components/avatar';
import styles from './searchResults.module.css';

interface SearchResult {
  type: 'post' | 'user' | 'hashtag';
  id: string;
  title: string;
  subtitle?: string;
  imageUrl?: string;
  count?: number;
}

interface SearchResultsProps {
  results: SearchResult[];
}

export const SearchResults: React.FC<SearchResultsProps> = ({ results }) => {
  const grouped = {
    posts: results.filter(r => r.type === 'post'),
    users: results.filter(r => r.type === 'user'),
    hashtags: results.filter(r => r.type === 'hashtag'),
  };

  return (
    <div className={styles.results}>
      {grouped.posts.length > 0 && (
        <div className={styles.section}>
          <h3>Posts</h3>
          {grouped.posts.map(result => (
            <ResultItem key={result.id} result={result} />
          ))}
        </div>
      )}
      {grouped.users.length > 0 && (
        <div className={styles.section}>
          <h3>People</h3>
          {grouped.users.map(result => (
            <ResultItem key={result.id} result={result} />
          ))}
        </div>
      )}
      {grouped.hashtags.length > 0 && (
        <div className={styles.section}>
          <h3>Hashtags</h3>
          {grouped.hashtags.map(result => (
            <ResultItem key={result.id} result={result} />
          ))}
        </div>
      )}
    </div>
  );
};

const ResultItem: React.FC<{ result: SearchResult }> = ({ result }) => (
  <div className={styles.resultItem}>
    {result.imageUrl && <Avatar src={result.imageUrl} />}
    <div>
      <p className={styles.title}>{result.title}</p>
      {result.subtitle && <p className={styles.subtitle}>{result.subtitle}</p>}
    </div>
  </div>
);`,
  },

  // Database
  {
    id: 'file-26',
    name: 'database.config.ts',
    conceptId: 'database',
    description: 'Database configuration and connection setup. Initializes the database connection pool.',
    exports: ['DatabaseConfig', 'getConnection', 'initializeDatabase'],
    codeSnippet: `import { Pool, PoolClient } from 'pg';

export class DatabaseConfig {
  private static instance: Pool;

  static getInstance(): Pool {
    if (!DatabaseConfig.instance) {
      DatabaseConfig.instance = new Pool({
        user: process.env.DB_USER || 'postgres',
        password: process.env.DB_PASSWORD,
        host: process.env.DB_HOST || 'localhost',
        port: parseInt(process.env.DB_PORT || '5432'),
        database: process.env.DB_NAME || 'instagram_clone',
        max: 20,
        idleTimeoutMillis: 30000,
        connectionTimeoutMillis: 2000,
      });

      DatabaseConfig.instance.on('error', (err) => {
        console.error('Unexpected error on idle client', err);
      });
    }
    return DatabaseConfig.instance;
  }

  static async getConnection(): Promise<PoolClient> {
    return DatabaseConfig.getInstance().connect();
  }

  static async initialize() {
    const pool = DatabaseConfig.getInstance();
    const client = await pool.connect();
    try {
      await client.query('SELECT NOW()');
      console.log('Database connection successful');
    } finally {
      client.release();
    }
  }

  static async close() {
    await DatabaseConfig.instance.end();
  }
}`,
  },
  {
    id: 'file-27',
    name: 'migrations.ts',
    conceptId: 'database',
    description: 'Database schema migrations. Creates and manages database tables and indexes.',
    exports: ['runMigrations', 'migrate', 'rollback'],
    codeSnippet: `import { Pool } from 'pg';

export const migrations = [
  {
    id: '001',
    name: 'Create users table',
    up: async (pool: Pool) => {
      await pool.query(\`
        CREATE TABLE users (
          id SERIAL PRIMARY KEY,
          username VARCHAR(255) UNIQUE NOT NULL,
          email VARCHAR(255) UNIQUE NOT NULL,
          password_hash VARCHAR(255) NOT NULL,
          display_name VARCHAR(255),
          bio TEXT,
          avatar_url VARCHAR(500),
          follower_count INT DEFAULT 0,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
      \`);
    },
  },
  {
    id: '002',
    name: 'Create posts table',
    up: async (pool: Pool) => {
      await pool.query(\`
        CREATE TABLE posts (
          id SERIAL PRIMARY KEY,
          author_id INT REFERENCES users(id),
          caption TEXT,
          image_url VARCHAR(500),
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          like_count INT DEFAULT 0,
          comment_count INT DEFAULT 0
        )
      \`);
    },
  },
];

export async function runMigrations(pool: Pool) {
  for (const migration of migrations) {
    await migration.up(pool);
    console.log(\`Ran migration: \${migration.name}\`);
  }
}`,
  },
  {
    id: 'file-28',
    name: 'models.index.ts',
    conceptId: 'database',
    description: 'Central index for all database models. Exports model classes for database entities.',
    exports: ['User', 'Post', 'Comment', 'Like', 'Follow', 'Notification'],
    codeSnippet: `export interface User {
  id: number;
  username: string;
  email: string;
  passwordHash: string;
  displayName: string;
  bio?: string;
  avatarUrl?: string;
  followerCount: number;
  followingCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface Post {
  id: number;
  authorId: number;
  caption: string;
  imageUrl: string;
  createdAt: Date;
  updatedAt: Date;
  likeCount: number;
  commentCount: number;
}

export interface Comment {
  id: number;
  postId: number;
  authorId: number;
  text: string;
  createdAt: Date;
  likeCount: number;
}

export interface Like {
  id: number;
  userId: number;
  postId?: number;
  commentId?: number;
  createdAt: Date;
}

export interface Follow {
  id: number;
  followerId: number;
  followingId: number;
  createdAt: Date;
}

export interface Notification {
  id: number;
  userId: number;
  type: string;
  actorId: number;
  targetId: number;
  isRead: boolean;
  createdAt: Date;
}`,
  },

  // Email
  {
    id: 'file-29',
    name: 'email.service.ts',
    conceptId: 'email',
    description: 'Service for sending emails. Handles user verification, password reset, and notifications.',
    exports: ['EmailService', 'sendVerificationEmail', 'sendPasswordResetEmail', 'sendNotificationEmail'],
    codeSnippet: `import nodemailer from 'nodemailer';
import { EmailTemplates } from './emailTemplates';

export class EmailService {
  private transporter: nodemailer.Transporter;

  constructor() {
    this.transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: process.env.SMTP_SECURE === 'true',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
      },
    });
  }

  async sendVerificationEmail(email: string, token: string) {
    const html = EmailTemplates.verificationEmail(token);
    return this.transporter.sendMail({
      from: process.env.SMTP_FROM,
      to: email,
      subject: 'Verify your Instagram account',
      html,
    });
  }

  async sendPasswordResetEmail(email: string, resetToken: string) {
    const html = EmailTemplates.passwordResetEmail(resetToken);
    return this.transporter.sendMail({
      from: process.env.SMTP_FROM,
      to: email,
      subject: 'Reset your password',
      html,
    });
  }

  async sendNotificationEmail(email: string, subject: string, message: string) {
    return this.transporter.sendMail({
      from: process.env.SMTP_FROM,
      to: email,
      subject,
      html: message,
    });
  }
}`,
  },
  {
    id: 'file-30',
    name: 'emailTemplates.ts',
    conceptId: 'email',
    description: 'HTML email templates for different notification types.',
    exports: ['EmailTemplates'],
    codeSnippet: `export class EmailTemplates {
  static verificationEmail(token: string): string {
    return \`
      <html>
        <body style="font-family: Arial, sans-serif;">
          <h1>Welcome to Instagram!</h1>
          <p>Please verify your email address by clicking the link below:</p>
          <a href="\${process.env.APP_URL}/verify?token=\${token}" style="background: #0095F6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
            Verify Email
          </a>
          <p>This link expires in 24 hours.</p>
        </body>
      </html>
    \`;
  }

  static passwordResetEmail(token: string): string {
    return \`
      <html>
        <body style="font-family: Arial, sans-serif;">
          <h1>Reset Your Password</h1>
          <p>Click the link below to reset your password:</p>
          <a href="\${process.env.APP_URL}/reset-password?token=\${token}" style="background: #0095F6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">
            Reset Password
          </a>
          <p>This link expires in 1 hour. If you didn't request this, ignore this email.</p>
        </body>
      </html>
    \`;
  }

  static notificationEmail(username: string, action: string): string {
    return \`
      <html>
        <body style="font-family: Arial, sans-serif;">
          <h2>\${username} \${action}</h2>
          <p>Check it out on Instagram!</p>
        </body>
      </html>
    \`;
  }
}`,
  },
];

export const sampleEdges = [
  { source: 'auth', target: 'database', label: 'stores data in' },
  { source: 'feed', target: 'posts', label: 'depends on' },
  { source: 'feed', target: 'profiles', label: 'depends on' },
  { source: 'posts', target: 'media', label: 'sends data to' },
  { source: 'posts', target: 'database', label: 'stores data in' },
  { source: 'profiles', target: 'media', label: 'sends data to' },
  { source: 'profiles', target: 'database', label: 'stores data in' },
  { source: 'notifications', target: 'posts', label: 'depends on' },
  { source: 'notifications', target: 'email', label: 'triggers' },
  { source: 'notifications', target: 'database', label: 'stores data in' },
  { source: 'auth', target: 'email', label: 'triggers' },
  { source: 'search', target: 'posts', label: 'depends on' },
  { source: 'search', target: 'profiles', label: 'depends on' },
  { source: 'search', target: 'database', label: 'depends on' },
  { source: 'media', target: 'database', label: 'stores metadata in' },
];

export const sampleFileImports = [
  { source: 'file-3', target: 'file-2' }, // login.screen.tsx -> auth.service.ts
  { source: 'file-4', target: 'file-2' }, // register.screen.tsx -> auth.service.ts
  { source: 'file-1', target: 'file-2' }, // auth.controller.ts -> auth.service.ts
  { source: 'file-5', target: 'file-6' }, // feed.screen.tsx -> feed.service.ts
  { source: 'file-5', target: 'file-7' }, // feed.screen.tsx -> feedItem.component.tsx
  { source: 'file-5', target: 'file-8' }, // feed.screen.tsx -> feed.hooks.ts
  { source: 'file-8', target: 'file-6' }, // feed.hooks.ts -> feed.service.ts
  { source: 'file-11', target: 'file-10' }, // createPost.screen.tsx -> post.service.ts
  { source: 'file-11', target: 'file-21' }, // createPost.screen.tsx -> imageUploader.component.tsx
  { source: 'file-13', target: 'file-9' }, // comments.component.tsx -> post.model.ts
  { source: 'file-12', target: 'file-9' }, // postCard.component.tsx -> post.model.ts
  { source: 'file-14', target: 'file-15' }, // profile.screen.tsx -> profile.service.ts
  { source: 'file-16', target: 'file-15' }, // editProfile.screen.tsx -> profile.service.ts
  { source: 'file-21', target: 'file-20' }, // imageUploader.component.tsx -> media.service.ts
  { source: 'file-23', target: 'file-24' }, // search.screen.tsx -> search.service.ts
  { source: 'file-23', target: 'file-25' }, // search.screen.tsx -> searchResults.component.tsx
  { source: 'file-17', target: 'file-18' }, // notifications.screen.tsx -> notification.service.ts
  { source: 'file-17', target: 'file-19' }, // notifications.screen.tsx -> pushNotification.handler.ts
  { source: 'file-18', target: 'file-19' }, // notification.service.ts -> pushNotification.handler.ts
  { source: 'file-29', target: 'file-30' }, // email.service.ts -> emailTemplates.ts
];
