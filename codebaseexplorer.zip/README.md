# Codebase Explorer

A mobile + web app that lets anyone — including people who have never touched code — upload a codebase and instantly understand what it does through a beautiful, interactive visual graph.

## Quick Start

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser. Click "Try the demo" to explore the sample Instagram-clone codebase, or drop a `.zip` file to analyze your own.

## Environment Variables

| Variable | Description | Required |
|---|---|---|
| `VITE_ENABLE_UPLOAD` | Set to `"true"` to enable real zip upload + Claude API analysis | No (demo works without it) |
| `VITE_API_ENDPOINT` | URL for your Claude API proxy endpoint (defaults to `/api/claude`) | Only if upload enabled |

## Architecture

**Framework:** Vite + React. We evaluated Expo/React Native Web but found that no RN-compatible library supports interactive force-directed canvas graphs with touch gestures. A responsive React web app delivers the same mobile + desktop experience with far less complexity.

**Graph Engine:** D3-force for physics simulation + custom HTML5 Canvas renderer. The vasturiano/force-graph library (23MB) was rejected in favor of a hand-rolled renderer (~2KB) that gives full control over the visual aesthetic — soft glows, emoji rendering, idle float animations, and node selection pulses that a pre-built library can't provide.

**State:** Zustand — a single store manages app state, selection, chat, and layout data with zero boilerplate.

**AI Integration:** Anthropic Claude API with structured JSON outputs. The codebase is sent as a file tree + sampled file contents, and Claude returns concept extraction, file descriptions, and semantic relationships as structured JSON. Behind a feature flag so the demo works without any API key.

**File Parsing:** JSZip for in-browser zip extraction + regex-based import detection across JS/TS/Python/Go/Rust. Tree-sitter WASM was evaluated but adds 2MB+ per language grammar — overkill for import detection in an MVP.

## Three-Layer Architecture

1. **Concept Map** (default) — AI-extracted concepts as force-directed bubbles with emojis, sized by file count, connected by semantic edges
2. **Files View** — Individual files grouped into soft dashed clusters by concept, with import edges shown on selection
3. **Code Walkthrough** — Split-screen with syntax-highlighted code and plain-English explanations

## Project Structure

```
src/
  components/    # React components (UploadScreen, GraphCanvas, InspectorPanel, etc.)
  store/         # Zustand state management
  data/          # Sample codebase data (Instagram clone)
  utils/         # Graph layout (d3-force), file parser (JSZip), Claude API client
```

## Tech Stack

- React 19 + Vite 8
- D3-force for graph physics
- HTML5 Canvas for rendering
- Zustand for state
- Tailwind CSS v4
- JSZip for zip processing
- Claude API (claude-sonnet-4-6) for AI analysis
